1 Application URL is located at
    https://apartmentmanagerse3.azurewebsites.net/

2 there are 4 different login types or modules for our website.
    a sample user for each is provided

    tenant       jake@albany.edu           
    admin        verla@albany.edu
    security     s@albany.edu
    maintenance  m@albany.edu

    We have set all passwords to 12345678 to make testing easy

3 github URL
    https://github.com/Ralphd42/APARTMENTMANAGEMENT

    We have added the TA ninand to our github.


4 DOTNET CORE
    you will need .net core to run this Application
    you can get this from 
    https://dotnet.microsoft.com/download

    this app uses the dotnetcore react template.

    to run the app go to your root directory and type 
    dotnet run

    there are two config files
     appsettings.json
     ClientApp/.env

     These should not have to be modified.
     -If you want to build the react indepenet of the 
     full dot net build
     go to the clientApp folder 
     and run
     npm run build
    -If you want to create your own database the full schema is located at
    Database Schema/FULLDATABASE.sql
    -The team wouldn't recommend this.  The team has always used the Database on azure.








