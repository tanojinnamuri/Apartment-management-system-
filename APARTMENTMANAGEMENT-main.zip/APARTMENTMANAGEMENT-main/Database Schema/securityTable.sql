/****** Object:  Table [dbo].[securityTable]    Script Date: 19-09-2021 10.56.52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[securityTable](
	[securityID] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](30) NULL,
	[jobTitle] [varchar](40) NULL,
	[salary] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[securityID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[username] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[securityTable]  WITH CHECK ADD FOREIGN KEY([username])
REFERENCES [dbo].[mainTable] ([username])
GO

