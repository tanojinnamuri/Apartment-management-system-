/****** Object:  Table [dbo].[adminTable]    Script Date: 19-09-2021 10.56.24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[adminTable](
	[adminID] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](30) NULL,
	[telephoneNumber] [varchar](15) NULL,
	[jobTitle] [varchar](60) NULL,
PRIMARY KEY CLUSTERED 
(
	[adminID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[username] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[adminTable]  WITH CHECK ADD FOREIGN KEY([username])
REFERENCES [dbo].[mainTable] ([username])
GO

