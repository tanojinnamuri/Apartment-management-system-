/****** Object:  Table [dbo].[maintenanceTable]    Script Date: 19-09-2021 10.56.39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[maintenanceTable](
	[maintenanceID] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](30) NULL,
	[jobTitle] [varchar](40) NULL,
PRIMARY KEY CLUSTERED 
(
	[maintenanceID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[username] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[maintenanceTable]  WITH CHECK ADD FOREIGN KEY([username])
REFERENCES [dbo].[mainTable] ([username])
GO

