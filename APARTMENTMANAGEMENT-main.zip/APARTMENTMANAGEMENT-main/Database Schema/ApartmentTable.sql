/****** Object:  Table [dbo].[ApartmentTable]    Script Date: 22-09-2021 1.36.34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ApartmentTable](
	[houseID] [varchar](10) NOT NULL,
	[username] [varchar](30) NULL,
	[houseNo] [int] NULL,
	[blockId] [varchar](10) NULL,
PRIMARY KEY CLUSTERED 
(
	[houseID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[username] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ApartmentTable]  WITH CHECK ADD FOREIGN KEY([username])
REFERENCES [dbo].[mainTable] ([username])
GO

