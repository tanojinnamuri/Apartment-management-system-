/****** Object:  Table [dbo].[MainReq]    Script Date: 19-09-2021 10.57.14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MainReq](
	[MainReqID] [int] IDENTITY(1,1) NOT NULL,
	[RequestorUN] [varchar](30) NOT NULL,
	[HandlerID] [varchar](30) NULL,
	[RequestMessage] [varchar](max) NOT NULL,
	[ResponseMessage] [varchar](max) NULL,
	[Requested] [datetime] NOT NULL,
	[Resolved] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[MainReqID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[MainReq] ADD  DEFAULT (getdate()) FOR [Requested]
GO

ALTER TABLE [dbo].[MainReq]  WITH CHECK ADD FOREIGN KEY([HandlerID])
REFERENCES [dbo].[mainTable] ([username])
GO

ALTER TABLE [dbo].[MainReq]  WITH CHECK ADD FOREIGN KEY([RequestorUN])
REFERENCES [dbo].[mainTable] ([username])
GO

