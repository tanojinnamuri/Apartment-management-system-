/****** Object:  StoredProcedure [dbo].[GetParkingInfoForUser]    Script Date: 10/14/2021 6:17:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create  Procedure [dbo].[GetParkingInfoForUser](@username varchar(100))
as
begin 
select p.ParkingSpaceID,
	p.SpaceNumber, 
	isnull(m.username,'') as UserEmail, 
	p.active, 
	isnull(m.firstName,'') + '' + isnull(m.lastName,'') as UserName, 
	isnull(b.buildingName,'') as BuildingName, p.Restype
from 
	ParkingSpace p left  join 
	mainTable m on p.UserName = m.username left join 
	ParkingLot l on l.ParkingLotID = p.ParkingLotID   left join 
	Building b on b.BuildingID = p.BuildingID where p.UserName = @username
end
GO

