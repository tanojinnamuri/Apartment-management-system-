/****** Object:  StoredProcedure [dbo].[clearSpot]    Script Date: 10/14/2021 6:16:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE  Procedure [dbo].[clearSpot](@SpotID int )
as
begin

	update parkingSpace set username=null where  ParkingSPaceID =@SpotID



end
GO

