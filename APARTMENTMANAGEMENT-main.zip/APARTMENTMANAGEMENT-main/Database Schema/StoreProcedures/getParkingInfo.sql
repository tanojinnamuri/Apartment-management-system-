/****** Object:  StoredProcedure [dbo].[GetParkingInfo]    Script Date: 10/14/2021 6:16:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  Procedure [dbo].[GetParkingInfo]
as
begin 
select p.ParkingSpaceID,
	p.SpaceNumber, 
	isnull(m.username,'') as UserEmail, 
	p.active, 
	isnull(m.firstName,'') + '' + isnull(m.lastName,'') as UserName, 
	isnull(b.buildingName,'') as BuildingName,
	case 
	when  p.username is null then ''
	 when Restype ='g' then 'Guest'
		else 'Tenent'
	END as restype
from 
	ParkingSpace p left  join 
	mainTable m on p.UserName = m.username left join 
	ParkingLot l on l.ParkingLotID = p.ParkingLotID   left join 
	Building b on b.BuildingID = p.BuildingID
end
GO

