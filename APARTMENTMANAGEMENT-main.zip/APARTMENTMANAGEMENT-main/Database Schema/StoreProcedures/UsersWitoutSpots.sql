/****** Object:  StoredProcedure [dbo].[UsersWitoutSpots]    Script Date: 10/14/2021 6:19:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE proc [dbo].[UsersWitoutSpots]
as
begin
	select distinct(username)    from mainTable where username not in( select username from ParkingSpace where Restype<>'g' and UserName is not null) 

end
GO

