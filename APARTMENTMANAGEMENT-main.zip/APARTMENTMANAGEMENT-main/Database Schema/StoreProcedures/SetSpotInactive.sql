/****** Object:  StoredProcedure [dbo].[SetSpotInactive]    Script Date: 10/14/2021 6:18:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  Procedure [dbo].[SetSpotInactive](@SpotID int )
as
begin 
	declare @curAct bit
	declare @hasTen varchar(30)
	select @hasten =isnull(Username,'EMPTY')  , @curAct =active from parkingspace 
	where ParkingSPaceID =@SpotID
	if(@hasten = 'EMPTY' or @curAct=0) 
	begin
	update parkingSpace set active =active ^1 where  ParkingSPaceID =@SpotID
	end

end
GO

