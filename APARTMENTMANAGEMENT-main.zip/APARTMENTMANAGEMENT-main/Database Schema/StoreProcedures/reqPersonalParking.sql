/****** Object:  StoredProcedure [dbo].[reqPersonalParking]    Script Date: 10/14/2021 6:18:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  Procedure [dbo].[reqPersonalParking](@username varchar(100))
as
begin 
	set nocount on
	declare @msg varchar(500)
	declare @numGused int
	declare @Avail int
	select @numGused =count(*) from ParkingSpace p where p.UserName =@username and p.ResType = 't'
	if @numGused<=0
	begin
		select @Avail = min(ParkingSpaceID) from ParkingSpace where UserName is null and active =1
		if @avail is not null
		begin
			update ParkingSpace set UserName =@username, ResType ='t' where ParkingSpaceID =@avail
			set @msg ='Parking Added'
		end
		else
		begin
			set @msg ='No free spots'
		end
	end
	else
	begin
		set @msg = 'User already has parking'
	end
	select @msg
	end
GO

