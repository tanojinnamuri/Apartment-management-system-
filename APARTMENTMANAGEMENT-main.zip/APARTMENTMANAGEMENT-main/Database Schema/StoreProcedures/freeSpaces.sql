/****** Object:  StoredProcedure [dbo].[freeSpaces]    Script Date: 10/14/2021 6:16:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create proc [dbo].[freeSpaces]
as
begin
	select ParkingSpaceID, SPaceNumber from    ParkingSpace where UserName is null

end
GO

