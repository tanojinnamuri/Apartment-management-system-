/****** Object:  StoredProcedure [dbo].[addSpot]    Script Date: 10/14/2021 6:11:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create  Procedure [dbo].[addSpot](@SpaceNumber varchar(30))
as
begin
	insert into ParkingSpace(SpaceNumber, Restype) values(@SpaceNumber,'t')
end
GO


