/****** Object:  Table [dbo].[mainTable]    Script Date: 19-09-2021 10.56.05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[mainTable](
	[username] [varchar](30) NOT NULL,
	[firstName] [varchar](30) NOT NULL,
	[lastName] [varchar](30) NOT NULL,
	[profilePicture] [image] NULL,
	[phoneNumber] [varchar](10) NULL,
	[pw_hash] [char](60) NULL,
	[u_type] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[username] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[mainTable]  WITH CHECK ADD FOREIGN KEY([u_type])
REFERENCES [dbo].[UserType] ([UserTypeID])
GO

