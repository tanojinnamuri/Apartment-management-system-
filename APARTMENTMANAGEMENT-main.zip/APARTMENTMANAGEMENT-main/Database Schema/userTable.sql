/****** Object:  Table [dbo].[userTable]    Script Date: 19-09-2021 10.57.03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[userTable](
	[userID] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](30) NULL,
	[telephoneNumber] [varchar](15) NULL,
	[flatNumber] [varchar](10) NULL,
	[parkingSpot] [varchar](30) NULL,
	[peopleInFlat] [int] NULL,
	[flatDescription] [text] NULL,
	[specialReq] [text] NULL,
PRIMARY KEY CLUSTERED 
(
	[userID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[username] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[userTable]  WITH CHECK ADD FOREIGN KEY([username])
REFERENCES [dbo].[mainTable] ([username])
GO

