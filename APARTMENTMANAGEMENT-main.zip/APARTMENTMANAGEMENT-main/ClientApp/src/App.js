import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import { MainDashboard } from './components/MainDashboard';
import './custom.css'
import './components/Login';
import AboutUs from "./components/AboutUs";
import ForgotPwd from "./components/ForgotPwd"
export default class App extends Component {
  static displayName = App.name;
  
  


  
  render() {




    return (<Router>
      <div className="App">
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <div className="container text-center" >
              <Link className="navbar-brand" to={"/sign-in"} ><h1 style={{ color: 'white' }}>Apartment Management System</h1></Link
              >
            </div>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto">


                <li className="nav-item">

                  <Link className="nav-link" to={"/aboutus"} ><h6 style={{ color: 'white' }} className="text-right">About us</h6></Link>

                </li>



              </ul>
            </div>

          </div>
        </nav>

        <div className="auth-wrapper">
          <div className="auth-inner">
            <Switch>
              <Route exact path='/' component={MainDashboard} />
              <Route path="/sign-in" component={MainDashboard} />
              <Route path="/aboutus" component={AboutUs} />
              <Route path="/ForgotPwd" component={ForgotPwd} />
            </Switch>
          </div>
        </div>
      </div></Router>
    );





  }






}
