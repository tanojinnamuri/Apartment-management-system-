import React, { Component } from "react";
import { DetailsList } from '@fluentui/react';
export default class TParking extends Component {
    static displayName = TParking.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ParkingData: [],msg:""
        }
        this.PopulatePDS = this.PopulatePDS.bind(this);
        this.CreateRequest = this.CreateRequest.bind(this);
        this.CancelRequest = this.CancelRequest.bind(this);
    }
    _columns = [
        { key: 'spaceNumber', name: 'Space Number', fieldName: 'spaceNumber', minWidth: 50, isResizable: false ,width:100},
        { key: 'restype', name: 'Tenant or Guest', fieldName: 'restype', minWidth: 50, isResizable: true,width:100 }
        
    ];
    componentDidMount() {


        this.PopulatePDS();
        
      }


    render() {
        return (<div>
            <h4>Parking Spaces</h4>
            <DetailsList 
            items={this.state.ParkingData}
            columns={this._columns}
            selectionMode={0}
            onRenderItemColumn={this._renderItemColumn}
        />
            <br />
            
            <form>
        <h4>Submit a guest parking request</h4>



<button type="submit" className="btn btn-primary btn-block" onClick={this.CreateRequest}>Submit Request </button>
<button type="submit" className="btn btn-primary btn-block" onClick={this.CancelRequest}>Cancel Request </button>
        </form>
        <div>MSG: {this.state.msg }</div>
        </div>
        );
    }
    PopulatePDS() {
        var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "GetTenParkingDetails?username=" +userId;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ParkingData: data });
            console.log(data);
        });
    }
    CreateRequest(e) {
        e.preventDefault();
        this.setState({ msg: "" });
        var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "reqParking?username=" +userId;
        fetch(url).then(res => res.json()).then((data) => {
            console.log("msg:");
            console.log("msg:" + data);
            this.setState({ msg: data });
            console.log(data);
            this.PopulatePDS();
        });
        
    }
    CancelRequest(e) {
        e.preventDefault();
        this.setState({ msg: "" });
        var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "canParking?username=" +userId;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ msg: "itemsremoved " + data });
            this.PopulatePDS();
            console.log(data);
        });
        


     }





}