import React, { Component } from "react";
import ParkingDetailsNT from './ParkingDetailsNT'
export default class ParkingNT extends Component {
    static displayName = ParkingNT.name;
    render() {
        return (
            <div>
                <ParkingDetailsNT/>
            </div>
        );
    }
}