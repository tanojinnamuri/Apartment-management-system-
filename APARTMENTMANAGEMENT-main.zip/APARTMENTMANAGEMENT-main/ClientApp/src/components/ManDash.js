import React, { Component } from 'react';

import { ManagerReq } from './ManagerReq';
import { ManagerReqC } from './ManagerReqC';
import CreateMaintenanceAnnouncements from './CreateMaintenanceAnnouncements';
import UpdateProfileMaintenance from './UpdateProfileMaintenance';
export class ManDash extends Component {
  static displayName = ManDash.name;
  constructor(props) {
    super(props);

    this.state =
    {
      activity: <div>Management Console for {this.props.AuthTkn.firstName}</div>
    }
    this.GoToMaint = this.GoToMaint.bind(this);
    this.GoToPlumbing = this.GoToPlumbing.bind(this);
    this.GoToProfile = this.GoToProfile.bind(this);
    this.GoToPastWork = this.GoToPastWork.bind(this);
    this.GoToAnnounce = this.GoToAnnounce.bind(this);
  }
  GoToMaint() {
    var mr = <ManagerReq AuthTkn={this.props.AuthTkn} PastWork={false} ></ManagerReq>
    this.setState({
      activity: mr

    });


  }
  GoToPlumbing() {
    var mr = <div>Sorry under construction</div>
    this.setState({
      activity: mr

    });



  }
  GoToProfile() {
    var mr = <UpdateProfileMaintenance AuthTkn={this.props.AuthTkn} PastWork={true}></UpdateProfileMaintenance>
    this.setState({
      activity: mr

    });


  }
  GoToPastWork() {
    var mr = <ManagerReqC AuthTkn={this.props.AuthTkn} PastWork={true}></ManagerReqC>
    this.setState({
      activity: mr

    });


  }
 // GoToAnnounce
 GoToAnnounce() {
  var mr = <CreateMaintenanceAnnouncements AuthTkn={this.props.AuthTkn} PastWork={true}></CreateMaintenanceAnnouncements>
  this.setState({
    activity: mr

  });


}

  render() {
    let FullName = this.props.AuthTkn.firstName + ' ' + this.props.AuthTkn.lastName;
    return (<div><nav className="navbar navbar-expand-lg navbar-light fixed-top">
      <div className="container">
        <div className="container text-center" >
          <h1 style={{ color: 'white' }}>Manager Name:{FullName}</h1>
        </div>
        <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul className="navbar-nav ml-auto" style={{ liststyletype: 'none' }}>

          

            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.GoToMaint}><h6 style={{ color: 'white' , fontSize: '11px'}} className="text-right">Requests</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.GoToPastWork}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Completed Requests</h6></button>

            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.GoToAnnounce}><h6 style={{ color: 'white' , fontSize: '11px'}} className="text-right">Announce Maintenance</h6></button>

            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.GoToProfile}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Update Profile</h6></button>
            </li>
            <li className="nav-item">
               <a href="https://apartmentmanagerse3.azurewebsites.net/"><button className="btn btn-sm nav-link"><h6 style={{ color: 'white', fontSize: '11px' }}>Log Out</h6></button></a>
            </li>


          </ul>
        </div>

      </div>
    </nav>
     

      <div style={{ width: '100%' }} >{this.state.activity} </div>

      
    </div>);
  }
}