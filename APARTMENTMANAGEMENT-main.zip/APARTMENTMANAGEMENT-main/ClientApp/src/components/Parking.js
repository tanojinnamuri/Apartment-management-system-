import React, { Component } from "react";
import ParkingDetails from './ParkingDetails'
export default class Parking extends Component {
    static displayName = Parking.name;
    render() {
        return (
            <div>
                <ParkingDetails/>
            </div>
        );
    }
}