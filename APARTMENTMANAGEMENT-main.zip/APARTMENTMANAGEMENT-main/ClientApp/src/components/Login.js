import React, { Component } from 'react';

export class Login extends Component {
  static displayName = Login.name;
  constructor(props) {
    super(props);
    this.state = {
      emailAddress: "",
      pwd: ""
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(evt) {
    this.setState({
      [evt.target.name]: evt.target.value
    });

  }


  LoginUser = (e) => {
    e.preventDefault();
    let userInfo = {
      emailAddress: this.state.emailAddress,
      pwd: this.state.pwd

    };


    fetch(process.env.REACT_APP_APIURL +'LogInuser', {
      method: 'POST',
      headers: { 'Content-type': 'application/json' },
      body: JSON.stringify(userInfo)
    }).then(r => r.json()).then(res => {

      if (res) {
        this.props.authfunc(res);
      } else {
        alert("Failed to log in");
      }
    }).catch( error=>alert("THere was an error logging.  Are you sure you have the correct credentials?"));

  }

  
    render(){ 
    return (
      <div>
        <form>
        <h3>Log In</h3>

<div className="form-group">
    <label>User Id</label>
    <input type="email"  name="emailAddress"  className="form-control" placeholder="Enter user ID" onChange={this.handleChange}  />
</div>

<div className="form-group">
    <label>Password</label>
    <input type="password"  name="pwd" className="form-control" placeholder="Enter password"    onChange={this.handleChange} />
</div>

<div className="form-group">
    <div className="custom-control custom-checkbox">
        <input type="checkbox" className="custom-control-input" id="customCheck1" />
        <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
    </div>
</div>

<button type="submit" className="btn btn-primary btn-block" onClick={this.LoginUser}>Submit</button>
<p className="forgot-password text-right">
    Forgot  password? 
</p>
        </form>
      </div>
    );







  }
}
