import React, { Component } from 'react';
import { DetailsList, mergeStyles } from '@fluentui/react';
const manStyle = mergeStyles({


    width: '100%',
    fontSize: '11px'

});
/*
const ReqStyle = mergeStyles({
   
  color:'red',
   width: '100%',
   fontSize: '11px'
  
});
const ResStyle = mergeStyles({
   
   
   width: '100%',
   fontSize: '10px'
  
});
const DateReq = mergeStyles({
   
   
   width: '1px',
   fontSize: '11px'
  
});
const DateResp = mergeStyles({
   
   
   width: '1px',
   fontSize: '11px'
  
});

*/


export default class ViewGuestDetails extends Component {
    static displayName = ViewGuestDetails.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
        }

        this.PopulateManQueue = this.PopulateManQueue.bind(this);
    }



    _columns = [

        { className: manStyle, key: 'guestName', name: 'Name', fieldName: 'guest_Name', minWidth: 80, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'blockId', name: 'Block ID', fieldName: 'block_Id', minWidth: 100, maxWidth: 170, isResizable: true },
        { className: manStyle, key: 'houseNo', name: 'House Number', fieldName: 'house_No', minWidth: 100, maxWidth: 170, isResizable: true },
        { className: manStyle, key: 'guestNumber', name: 'Guest Mobile Number', fieldName: 'guest_Number', minWidth: 50, maxWidth: 100, isResizable: true },
        { className: manStyle, key: 'entryDate', name: 'Date of Entry', fieldName: 'entry_Date', minWidth: 50, maxWidth: 100, isResizable: true, isSortable : true}
    ];
    componentDidMount() {


        this.PopulateManQueue();

    }



    render() {

        return (
            <DetailsList
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />



        );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {

            case 'entryDate':
                rtval = new Date(fieldContent).toLocaleDateString();
                break;

            default:
                rtval = <span>{fieldContent}</span>;

        }
        return rtval;
    }

    PopulateManQueue() {
        var url = process.env.REACT_APP_APIURL + "ViewGuestDetails";
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ManagedItems: data });
            console.log(data);
        });

    }


}