import React, { Component } from 'react';
import { DetailsList, mergeStyles } from '@fluentui/react';
const manStyle = mergeStyles({


    width: '100%',
    fontSize: '11px'

});

export  class ViewAnnouncements extends Component {
    static displayName = ViewAnnouncements.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
        }

        this.PopulateManQueue = this.PopulateManQueue.bind(this);
    }



    _columns = [

        { ClassName: manStyle, key: 'a_type', name: 'Announcement Type', fieldName: 'a_type', minWidth: 60, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'a_date', name: 'Date', fieldName: 'a_date', minWidth: 60, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'a_priority', name: 'Priority', fieldName: 'a_priority', minWidth: 50, maxWidth: 170, isResizable: true },
        { className: manStyle, key: 'a_text', name: 'Announcement', fieldName: 'a_text', minWidth: 400, maxWidth: 170, isResizable: true }

    ];
    componentDidMount() {


        this.PopulateManQueue();

    }  



    render() {

        return (
            <DetailsList
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />



        );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {

            case 'a_date':
                rtval = new Date(fieldContent).toLocaleDateString();
                break;

            default:
                rtval = <span>{fieldContent}</span>;

        }
        return rtval;
    }

    PopulateManQueue() {
        //var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "GetAllAnnouncements";
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({   ManagedItems: data  });
            console.log(data);
        });

    }


}