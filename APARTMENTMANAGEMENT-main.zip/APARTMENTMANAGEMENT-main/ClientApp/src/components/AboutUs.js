import React, { Component } from "react";

export default class AboutUs extends Component {
    render() {
        return (
            <div>
                <h3 style={{ color: "Red" }}><b>Albany Apartments</b></h3>
                <p><h3><b>LIFESTYLE, LUXURY & AWESOME LOCATION</b></h3></p>
                <p style={{ color: "light blue" }}> At the Albany Apartments, choose from spacious one-, two- or three-bedroom apartments, with private balconies, modern appliances and wall-to-wall carpeting. Amenities include two fitness centers, a pool, laundry centers in each building and intercom entry to every building.
                    Our apartments are located in Colonie, N.Y. just outside of Albany, N.Y., the Towers of Colonie is seconds away from all major highways, universities and shopping centers.</p>

                <ul>
                    <lh> <h2> Our Amenities </h2> </lh>
                    <li> Resident GYM </li>
                    <li> Air Conditioning Apartments</li>
                    <li> Hot water included </li>
                    <li> Custom window blinds </li>
                    <li> On CDTA Busline </li>
                </ul>
                <h4>Our residents love living here!</h4>
                <p> <b>Contact Us : +1-444-555-6666</b></p>
            </div>


        );
    }
}