import React, { Component } from "react";

export default class ForgotPwd extends Component {
    render() {
        return (
            <div>
                <h3>Forgot Password</h3>
                    <p>Contact Staff to get password renewed</p>
            </div>


        );
    }
}