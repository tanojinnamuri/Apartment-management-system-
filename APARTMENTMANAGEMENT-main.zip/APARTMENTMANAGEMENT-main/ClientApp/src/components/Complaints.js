import React, { Component } from "react";

export default class Complaints extends Component {
    static displayName = Complaints.name;
    constructor(props) {
        super(props);
        this.state = {
            ComplaintType: "",
            ComplaintText:"",
            ComplaintDate: "",
            ComplaintPriority: "",
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(evt) {
        this.setState({
            [evt.target.name]: evt.target.value
        });

    }

    CreateComplaint = (e) => {
        e.preventDefault();
        let Info = {
            c_text: this.state.ComplaintText,
            c_date: this.state.ComplaintDate,
            c_priority: this.state.ComplaintPriority,
            c_type: this.state.ComplaintType,
            c_requestor: this.props.AuthTkn.emailAddress,

        };


        fetch(process.env.REACT_APP_APIURL + 'AddComplaint', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(Info)
        }).then(r => r.json()).then(res => {
            console.log(res);
            if (res) {
                if (res === -1) {
                    alert("Failed to make a complaint 1");
                    this.setState({ added: false, Problem: "Failed to make a complaint 2" });
                }
                else {
                    this.setState({ added: true, Problem: "", TicketID: res });

                }
            } else {
                this.setState({ added: false, Problem: "Failed to make a complaint 4" });
            }
        });

    }
    render() {

        if (this.state.added){
            return(<div>Complaint is successfully posted </div>);
        }
        return (
            <div className="col">
                <form>
                    <h3>Make Complaint</h3>

                    <div className="form-group">
                        <label>Type</label>
                        
                        <select name="ComplaintType" className="form-control" placeholder="Enter complaint type" onChange={this.handleChange} >
                             <option value="None">None</option>
                             <option value="Admin">Admin</option>
                             <option value="Maintenance">Maintenance</option>
                             <option value="Security">Security</option>
                        </select>
                    </div>
                   
                    <div className="form-group">
                        <label>  Date</label>
                        <input type="date" name="ComplaintDate" className="form-control" placeholder="Enter  Date" onChange={this.handleChange} />
                    </div>

                    <div className="form-group">
                        <label> Priority</label>
                        
                        <select name="ComplaintPriority" className="form-control" placeholder="Enter priority" onChange={this.handleChange} >
                             <option value="None">None</option>
                             <option value="High">High</option>
                             <option value="Medium">Medium</option>
                             <option value="Low">Low</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Description</label>
                        <textarea type="text" name="ComplaintText" className="form-control" placeholder="Enter your concern" onChange={this.handleChange} />
                    </div>

                    <button type="submit" className="btn btn-primary btn-block" onClick={this.CreateComplaint}>Submit </button>

                </form>
                
            </div>
        );
    }
}