import React, { Component } from 'react';
import { DetailsList } from '@fluentui/react';

export class ManagerReq extends Component {
    static displayName = ManagerReq.name;
    constructor(props) {
        super(props);
        this.state =
        {
          ManagedItems: "",
          checked:true
        }
      this.PopulateManQueue = this.PopulateManQueue.bind(this);
      this.handleInputChange = this.handleInputChange.bind(this);
      this.AssignMaintReq = this.AssignMaintReq.bind(this);
      this._renderItemColumn = this._renderItemColumn.bind(this);
  }
  handleInputChange(event) {
    this.setState({ checked: event.target.checked });
    this.PopulateManQueue(event.target.checked);
  }
    _columns = [
        { key: 'requestorID', name: 'Requestor', fieldName: 'requestorID', minWidth: 50, maxWidth: 75, isResizable: true },
        { key: 'handlerName', name: 'Manager', fieldName: 'handlerName', minWidth: 50, maxWidth: 75, isResizable: true },
        { key: 'requestMessage', name: 'Request', fieldName: 'requestMessage', minWidth: 100, maxWidth: 200, isResizable: true },
        { key: 'responseMessage', name: 'Response', fieldName: 'responseMessage', minWidth: 100, maxWidth: 200, isResizable: true },
        { key: 'requested', name: 'Date Requested', fieldName: 'requested', minWidth: 50, maxWidth: 100, isResizable: true },
     
      { key: 'assign', name: 'Assign to me', fieldName: 'assign', minWidth: 50, maxWidth: 100, isResizable: true }
    ];
    componentDidMount() {


      this.PopulateManQueue(true);
      
    }



    render() {
      var msg = "All Requests for system";
      if (!this.state.checked) {
        msg = "Requests for " + this.props.AuthTkn.firstName + ' ' + this.props.AuthTkn.lastName;
      }
      return (<div>
          <div><h3>Open Management Requests</h3></div>
         < div class="checkbox">
          <label><input type="checkbox"
            onChange={this.handleInputChange}
              checked={this.state.checked}
              
            name="AllReq" id="AllReq"
              />All Requests</label>
 </div>
        <div>{ msg}</div>
          
        <div className="scroll"><DetailsList 
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            /></div>

</div>

         );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {
          case 'requestorID':
            
            rtval = <div>
              name: {item['requestorName']} <br />
              email:{fieldContent}          <br />
              Apartment:{item['apartment']} <br />
              phone:{item['requestorPhone']}


            </div>
            
            
            
            break;
          case 'requestorName':
          rtval = <div>
          name: {fieldContent} <br />
          email:{item['HandlerID']}          <br />
          
          phone:{item['handlerPhone']}


        </div>
            
            
            break;
          
          
          
          
          
          
          
          
          case 'responseMessage':
            if (item["handlerID"] === null) { rtval = <div>Unassigned</div> }
            else {
              var cv =""
              rtval =
                <div>
                  <textarea onChange=
                    {(e) => { cv = e.target.value; }}   >
                  </textarea><br />
                  <button className="btn btn-primary  btn-sm"
                    onClick={(e) => { e.preventDefault(); this.ResolveMaintReq(item["requestID"], cv); }}>
                    Resolve
                  </button>
                </div>
            }
            break;
          case 'requested':
            rtval = new Date(fieldContent).toLocaleDateString();
            
          break;
          //dateStarted
          case 'assign':
            if(item["handlerID"]===null){
              rtval =<button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault(); this.AssignMaintReq( item["requestID"]); }}>Take</button>
            }
          break;
           
    
          default:
            rtval= <span>{fieldContent}</span>;

        }
        return rtval;
      }





    PopulateManQueue(all) {
      var managerId = this.props.AuthTkn.emailAddress;
      if (all === true) {
        managerId = "";
      }
      var url = process.env.REACT_APP_MAINTAPIURL + "GetManagementRequests?managerId=" + managerId;
      if (this.props.PastWork ) {
        url = process.env.REACT_APP_MAINTAPIURL + "GetClosedRequests?managerId=" + managerId;
      }
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ManagedItems: data });
            console.log(data);
        });

  }
  
  AssignMaintReq(reqID) {
    let ManagementRequest = {
      HandlerID: this.props.AuthTkn.emailAddress,
      requestID: reqID
    };


    fetch(process.env.REACT_APP_MAINTAPIURL + 'AssignMaintReq', {
      method: 'POST',
      headers: { 'Content-type': 'application/json' },
      body: JSON.stringify(ManagementRequest)
    }).then(r => r.json()).then(res => {
      // repopulate grid
      this.PopulateManQueue(this.state.checked);
    });
  }


  ResolveMaintReq(reqID,msg) {
    let ManagementRequest = {
      HandlerID: this.props.AuthTkn.emailAddress,
      requestID: reqID,
      ResponseMessage:msg
    };


    fetch(process.env.REACT_APP_MAINTAPIURL + 'ResolveMaintReq', {
      method: 'POST',
      headers: { 'Content-type': 'application/json' },
      body: JSON.stringify(ManagementRequest)
    }).then(r => r.json()).then(res => {
      // repopulate grid
      this.PopulateManQueue(this.state.checked);
    });
  }





  


}