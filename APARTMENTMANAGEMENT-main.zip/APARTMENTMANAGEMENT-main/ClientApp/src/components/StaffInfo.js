import React, { Component } from "react";
import { DetailsList } from '@fluentui/react';
import Select from 'react-select'
//import Select from 'react-select'
export class StaffInfo extends Component {
    static displayName = StaffInfo.name;
    constructor(props) {
        super(props);
        this.state =
        {
            so: null,
            TD: [],
            ATEN:[],
        }
        //this.PopulateRAS = this.PopulateRAS.bind(this);
        this.handleChange = this.handleChange.bind(this);
        //this.PopulateTDS = this.PopulateTDS.bind(this);
        this.getAllStaff = this.getAllStaff.bind(this);
        this._renderItemColumn = this._renderItemColumn.bind(this);

        this.componentDidMount = this.componentDidMount.bind(this);
        this.RemoveUser = this.RemoveUser.bind(this);
    }
    handleChange(evt) {
        console.log(evt.target.name);
        console.log(evt.target.value);
        this.setState({
            [evt.target.name]: evt.target.value
        });


    }
    componentDidMount() {
        //this.interval = setInterval(this.PopulatePDSInt, (1000 * 30));
       // this.PopulateTDS();
        this.getAllStaff();

        //this.interval = setInterval(this.PopulateRAS, (1000 * 30));
    }
    handleSChange = (selectedOption) => {
        this.setState({ so: selectedOption });

    }
      
    RemoveUser(un, Pwd)
    {
        
        let UserInfo = {
            emailAddress:un,
             
             
             
        };
         

        console.log(UserInfo);
        fetch(process.env.REACT_APP_APIURL + 'RemoveUser', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(UserInfo)
        }).then(res => res.json()).then((data) => {
            console.log('getAllStaff');
            this.getAllStaff();
            console.log('getAllStaff');
        });
        

    }





    render() {
      var   txtbx = {
            width: 120,
            fontSize:10
           
           
        };
        return (
            <div >
                <div><h4>Staff Management</h4></div>
                <div className="row">
                    <div className="col">
                        First Name:&nbsp;<input type="text" name="firstName" onChange={this.handleChange}  style={txtbx} ></input><br />
                        Last Name:&nbsp;<input type="text" name="lastName" onChange={this.handleChange} style={txtbx} ></input><br />
                        
                    </div>
                    <div className="col" >
                        Email:&nbsp;<input type="text" name="username" onChange={this.handleChange} style={txtbx} ></input><br />
                        Phone:&nbsp;<input type="text" name="telephoneNumber" onChange={this.handleChange} style={txtbx} ></input><br />
                        Title:&nbsp;<input type="text" name="jobTitle" onChange={this.handleChange} style={txtbx} ></input>
                    </div>
                    <div className="col">
                        Staff Type:   <Select onChange={this.handleSChange} className="pm" options={this._sOptions}></Select>
                    </div>
                    <div className="col">
                        <button className="btn btn-primary  btn-sm" onClick={this.CreateRequest} >Add User</button>

                    </div>
                </div>
                <div className="scroll"><DetailsList
                    items={this.state.ATEN}
                    columns={this._columns}
                    selectionMode={0}
                    onRenderItemColumn={this._renderItemColumn}
                /></div>
            </div>

        );
    }


    getAllStaff() {
        var url = process.env.REACT_APP_APIURL + "getAllStaff";
        this.setState({ ATEN: [] });
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ATEN: data });
            console.log(data);
        });
    }
    
    _columns = [
        { key: 'username', name: 'Staff Information', fieldName: 'username', minWidth: 25, maxWidth: 150, isResizable: true },
        //{ visible:false, key: 'parkingSpaceID', name: '', fieldName: 'parkingSpaceID', minWidth: 0, maxWidth: 1, isResizable: false ,innerWidth:0, outerWidth:0 },
        { key: 'jobTitle', name: 'Title', fieldName: 'jobTitle', minWidth: 25, maxWidth: 150, isResizable: true },
        { key:'updatePwd',name:'Update Pwd',fieldName:'username', minWidth: 25, maxWidth: 150, isResizable: true } 
        ,
        { key: 'DeleteUser', name: 'Remove User', fieldName: 'username', minWidth: 25, maxWidth: 150, isResizable: true }
    
    ];

    _sOptions = [
        { value: '2', label: 'Admin'       },
        { value: '3', label: 'Security'    },
        { value: '4', label: 'Maintenance' }
      ]




    _renderItemColumn(item, index, column) {

        var cv;
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {
            case 'username':
                rtval = <div>name:{item['firstName'] + ' ' + item['lastName']}<br />
                    email:{item['username']} <br />
                    phone:{item['telephoneNumber']}
                </div>
                break;

            case 'jobTitle':
                rtval = <div>Job Title:{item['jobTitle']}<br />
                    Role:{item['role']} <br />
                    
                </div>
                break;
                case 'updatePwd':
                    rtval = <div>
                        <input type="password" name="pw"
                            onChange={(e) => { cv = e.target.value; this.setState({ ["pw" + index]: cv }); }} ></input><br />
                        <button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault();  this.updatePwd(item['username'],this.state["pw" + index]) ; }}>Update Password</button>
                    </div>
                break;
                case 'DeleteUser':
                    rtval = <div>
                    
                        <button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault();  this.RemoveUser(item['username']) ; }}>Remove</button>
                    </div>
                
                    
                    
                    break;
            default:
                rtval = <span>{fieldContent}</span>;
        }
        return rtval;
    }

    CreateRequest = (e) => {
        console.log("CR1");
        let Tenant = {
            username: this.state.username,
            telephoneNumber: this.state.telephoneNumber,
            userTypeID: this.state.so.value,
            firstName: this.state.firstName,
            lastName: this.state.lastName ,
            jobTitle:this.state.jobTitle
            
        };
        console.log(Tenant);
        console.log("CR2");
        fetch(process.env.REACT_APP_APIURL + 'AddUpdateStaff', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(Tenant)
        }).then(r => r.json()).then(res => {
            console.log("CRRET");        
              console.log(res);
            if (res) {
                console.log("crOKAY");
                this.setState({ apiResp: res, isActive: true });
                  this.getAllStaff();
                  //this.PopulateTDS();
            } else {
                console.log("CRRETBAD");
                this.setState({ apiResp: "Error in adding Staff.  Please try again later" });
              }
              this.getAllStaff();
        });
            console.log("CR3");
    }
}