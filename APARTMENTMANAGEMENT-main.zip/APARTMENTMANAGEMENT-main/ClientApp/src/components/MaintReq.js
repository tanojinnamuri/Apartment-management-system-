import React, { Component } from 'react';

export class MaintReq extends Component {
  static displayName = MaintReq.name;
  constructor(props) {
    super(props);
    this.state = {
      Problem: "",
      RequestInfo: "",
      added: false,
      TicketID:-1

       
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(evt) {
    this.setState({
      [evt.target.name]: evt.target.value
    });

  }


  CreateRequest = (e) => {
    e.preventDefault();
    let ReqInfo = {
      RequestorID: this.props.AuthTkn.emailAddress,
      RequestMessage: this.state.RequestInfo

    };


    fetch(process.env.REACT_APP_APIURL +'AddMaintRequest', {
      method: 'POST',
      headers: { 'Content-type': 'application/json' },
      body: JSON.stringify(ReqInfo)
    }).then(r => r.json()).then(res => {
      console.log(res);
      if (res) {
        if (res === -1) {
          alert("Failed to add user");
          this.setState({ added: false,Problem:"Failed to create service request" });
        }
        else {
          this.setState({ added: true, Problem:"",TicketID:res });

        }
      } else {
        this.setState({ added: false,Problem:"Failed to create service request" });
      }
    });

  }

  
  render() {
      
    if (this.state.added) {
      return (<div>Thank you for making a request.  Your Ticket ID is {  this.state.TicketID }   </div>);


    }


    return (
      <div className="col">
        <form>
        <h3>Submit a service request</h3>

<div className="form-group">
    <label>Please describe your problem below</label>
    <textarea type="text"  name="RequestInfo"  className="form-control" placeholder="Enter your concern here " onChange={this.handleChange}  />
</div>

<button type="submit" className="btn btn-primary btn-block" onClick={this.CreateRequest}>Submit Request </button>
 
        </form>
        <div>{this.state.Problem }</div>
      </div>
    );







  }
}
