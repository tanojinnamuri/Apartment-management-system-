import React, { Component } from "react";

export default class AddGuestDetails extends Component {
    static displayName = AddGuestDetails.name;
    constructor(props) {
        super(props);
        this.state = {
            guest_Name: "",
            entry_Date:"",
            block_Id: "",
            house_No: "",
            guest_Number: ""
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(evt) {
        this.setState({
            [evt.target.name]: evt.target.value
        });

    }

    CreateGuest = (e) => {
        e.preventDefault();
        let ReqInfo = {
            guest_Name: this.state.guest_Name,
            block_Id: this.state.block_Id,
            house_No: this.state.house_No,
            guest_Number: this.state.guest_Number
        };


        fetch(process.env.REACT_APP_APIURL + 'AddGuest', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(ReqInfo)
        }).then(r => r.json()).then(res => {
            console.log(res);
            if (res) {
                if (res === -1) {
                    alert("Failed to add guest");
                    this.setState({ added: false, Problem: "Failed to add guest" });
                }
                else {
                    this.setState({ added: true, Problem: "", TicketID: res });

                }
            } else {
                this.setState({ added: false, Problem: "Failed to add guest" });
            }
        });

    }
    render() {

        if (this.state.added) {
            return (<div>Guest is successfully added </div>);
        }
        return (
            <div className="col">
                <form>
                    <h3>Add a guest</h3>
                    <div className="form-group">
                        <label> Guest Name</label>
                        <input type="text" name="guest_Name" className="form-control" placeholder="Enter Name of the Guest" onChange={this.handleChange} />
                    </div>
                    <div className="form-group">
                        <label> Block ID</label>
                        <input type="text" name="block_Id" className="form-control" placeholder="Enter Block ID" onChange={this.handleChange} />
                    </div>

                    <div className="form-group">
                        <label> House Number</label>
                        <input type="text" name="house_No" className="form-control" placeholder="Enter House Number" onChange={this.handleChange} />
                    </div>
                    <div className="form-group">
                        <label> Guest Phone Number</label>
                        <input type="text" name="guest_Number" className="form-control" placeholder="Enter Guest Phone Number" onChange={this.handleChange} />
                    </div>

                    <button type="submit" className="btn btn-primary btn-block" onClick={this.CreateGuest}>Add Guest</button>

                </form>

            </div>
        );
    }
}