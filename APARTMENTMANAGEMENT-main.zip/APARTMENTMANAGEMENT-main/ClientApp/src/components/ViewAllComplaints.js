import React, { Component } from 'react';
import { DetailsList, mergeStyles } from '@fluentui/react';
const manStyle = mergeStyles({


    width: '100%',
    fontSize: '11px'

});

export default class ViewAllCompaints extends Component {
    static displayName = ViewAllCompaints.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
        }

        this.PopulateManQueue = this.PopulateManQueue.bind(this);
    }



    _columns = [

        { className: manStyle, key: 'c_requestor', name: 'Requestor', fieldName: 'c_requestor', minWidth: 175, maxWidth: 280, isResizable: true },
        { className: manStyle, key: 'c_houseNo', name: 'House No', fieldName: 'c_houseNo', minWidth: 50, maxWidth: 70, isResizable: true },
        { className: manStyle, key: 'c_blockId', name: 'Block', fieldName: 'c_blockId', minWidth: 50, maxWidth: 70, isResizable: true },
        { ClassName: manStyle, key: 'c_type', name: 'Complaint Type', fieldName: 'c_type', minWidth: 60, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'c_date', name: 'Date', fieldName: 'c_date', minWidth: 60, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'c_priority', name: 'Priority', fieldName: 'c_priority', minWidth: 50, maxWidth: 70, isResizable: true },
        { className: manStyle, key: 'c_text', name: 'Description', fieldName: 'c_text', minWidth: 400, maxWidth: 170, isResizable: true }
    ];
    componentDidMount() {


        this.PopulateManQueue();

    }  



    render() {

        return (
            <DetailsList
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />



        );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {

            case 'c_date':
                rtval = new Date(fieldContent).toLocaleDateString();
                break;

            default:
                rtval = <span>{fieldContent}</span>;

        }
        return rtval;
    }

    PopulateManQueue() {
        //var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "GetAllComplaints";
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({   ManagedItems: data  });
            console.log(data);
        });

    }


}