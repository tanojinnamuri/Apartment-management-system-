import React, { Component } from "react";

export default class CreateNewEvent extends Component {
    static displayName = CreateNewEvent.name;
    constructor(props) {
        super(props);
        this.state = {
            EventDesc: "",
            EventLocation:"",
            EventDate: "",
            EventName: ""
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(evt) {
        this.setState({
            [evt.target.name]: evt.target.value
        });

    }

    CreateEvent = (e) => {
        e.preventDefault();
        let ReqInfo = {
            event_Description: this.state.EventDesc,
            event_Date: this.state.EventDate,
            event_Location: this.state.EventLocation,
            event_Name: this.state.EventName

        };


        fetch(process.env.REACT_APP_APIURL + 'AddEvent', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(ReqInfo)
        }).then(r => r.json()).then(res => {
            console.log(res);
            if (res) {
                if (res === -1) {
                    alert("Failed to post an event");
                    this.setState({ added: false, Problem: "Failed to post an event" });
                }
                else {
                    this.setState({ added: true, Problem: "", TicketID: res });

                }
            } else {
                this.setState({ added: false, Problem: "Failed to post an event" });
            }
        });

    }
    render() {

        if (this.state.added){
            return(<div>event is successfully posted </div>);
        }
        return (
            <div className="col">
                <form>
                    <h3>Post an event</h3>
                    <div className="form-group">
                        <label> Event Name</label>
                        <input type="text" name="EventName" className="form-control" placeholder="Enter Name of the Event" onChange={this.handleChange} />
                    </div>
                    <div className="form-group">
                        <label> Event Date</label>
                        <input type="text" name="EventDate" className="form-control" placeholder="Enter Event Date" onChange={this.handleChange} />
                    </div>

                    <div className="form-group">
                        <label> Event Location</label>
                        <input type="text" name="EventLocation" className="form-control" placeholder="Enter location" onChange={this.handleChange} />
                    </div>
                    <div className="form-group">
                        <label> Event Description</label>
                        <textarea type="text" name="EventDesc" className="form-control" placeholder="Enter Event Details" onChange={this.handleChange} />
                    </div>

                    <button type="submit" className="btn btn-primary btn-block" onClick={this.CreateEvent}>Submit Event </button>

                </form>
                
            </div>
        );
    }
}