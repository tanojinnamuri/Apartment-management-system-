import React, { Component } from 'react';
import { DetailsList } from '@fluentui/react';

export class ApartmentDetails extends Component {
    static displayName = ApartmentDetails.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
        }
        this.PopulateManQueue = this.PopulateManQueue.bind(this);
    }
    _columns = [
        { key: 'houseID', name: 'House ID', fieldName: 'houseID', minWidth: 80, isResizable: true },
        { key: 'username', name: 'Email', fieldName: 'username', minWidth: 150, isResizable: true },
        { key: 'houseNo', name: 'House Number', fieldName: 'houseNo', minWidth: 150, isResizable: true },
        { key: 'blockId', name: 'Block', fieldName: 'blockId', minWidth: 100, isResizable: true }
    ];
    componentDidMount() {


      this.PopulateManQueue();
      
    }



    render() {

        return ( 
            <DetailsList 
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />



         );
    }

    //_renderItemColumn(item, index, column) {
    //    const fieldContent = item[column.fieldName];//as string;
    //    var rtval;
    //    switch (column.key) {
          
    
    
    //      case 'requested':
    //        rtval = new Date(fieldContent).toLocaleDateString();
            
    //      break;
    //      //dateStarted
    //      case 'resolved':
    //        if(fieldContent===null){
    //          rtval = '';
    //        }else{ 
    //          rtval = new Date(fieldContent).toLocaleDateString();}
    //      break;
           
    
    //      default:
    //        rtval= <span>{fieldContent}</span>;

    //    }
    //    return rtval;
    //  }

    PopulateManQueue() {
        var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "GetApartmentDetails?userId=" + userId;
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ManagedItems: data });
            console.log(data);
        });
    }
}