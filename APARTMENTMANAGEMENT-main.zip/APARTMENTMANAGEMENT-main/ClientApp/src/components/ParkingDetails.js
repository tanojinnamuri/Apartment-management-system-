import React, { Component } from "react";
//import '@progress/kendo-theme-default/dist/all.css';
//import './all.css'

//import { process as kproc} from '@progress/kendo-data-query';

import { Grid, GridColumn } from '@progress/kendo-react-grid';
import { orderBy } from '@progress/kendo-data-query';
export default class ParkingDetails extends Component {
    static displayName = ParkingDetails.name;
    constructor(props) {

        super(props);
        this.state = {
            PD: [],
            sort: [
                { field: 'spaceNumber', dir: 'asc' }
            ], skip: 0,
            take: 2
        };
        this.PopulatePDS = this.PopulatePDS.bind(this);
        this.DisableSpot = this.DisableSpot.bind(this);
    }

    pageChange = (e) => {
        this.setState({
            skip: e.page.skip,
            take: e.page.take,
        });
    };


    PopulatePDS() {

        var url = process.env.REACT_APP_APIURL + "GetParkingDetails";
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ PD: data });
            console.log(data);
        });
    }

    DisableSpot(spotID) {
        console.log("SPOT ID is " + spotID);
        var url = process.env.REACT_APP_APIURL + "disableSpot?SpotID=" + spotID;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            if (data < 0) {
                alert("Can not disable parking if spot is assigned to a tenet");

            } else {
                // refresh the grid

                this.PopulatePDS();

            }

            console.log(data);
        });





    }


    componentDidMount() {
        this.PopulatePDS();
    }
    handleSortChange = (e) => {
        console.log(e.sort)
        this.setState({
            sort: e.sort
        });
    };

    render() {

        return (
            <Grid
                data={orderBy(this.state.PD, this.state.sort).slice(
                    this.state.skip,
                    this.state.take + this.state.skip
                )}
                sortable
                sort={this.state.sort}
                onSortChange={this.handleSortChange}
                pageable
                onPageChange={this.pageChange}
                skip={this.state.skip}
                take={this.state.take}
                total={this.state.PD.length}


            >

                <GridColumn field="spaceNumber" title="Space" width="auto" />

                <GridColumn field="userEmail" title="email" width="auto" />

                <GridColumn field="tenantName" title="Name" width="auto" />
                <GridColumn field="active" title="Active" cell={(props) => {
                    var aChk = false;
                    if (props.dataItem.active === "YES") { aChk = true; }


                    return (<td><input type="checkbox" checked={aChk}
                        onChange={(e) => { e.preventDefault(); console.log(props.dataItem); this.DisableSpot(props.dataItem.parkingSpaceID); }}

                    />
                    </td>);
                }
                }  width="100px" />


            </Grid>);

    }






}