import React, { Component } from "react";
import { DetailsList } from '@fluentui/react';
import Select from 'react-select'
export default class ParkingDetails extends Component {
    static displayName = ParkingDetails.name;
    constructor(props) {

        super(props);
        this.state = {
            PD: [],
            NP:[],
            spotName: "",
            so: null

        };
        this.PopulatePDS      =      this.PopulatePDS.bind(this);
        this.DisableSpot      =      this.DisableSpot.bind(this);
        this._renderItemColumn=this._renderItemColumn.bind(this);
        this.clearSpot        =        this.clearSpot.bind(this);
         
         
        this.handleChange = this.handleChange.bind(this);
         
    }
    setParking =(e)=>
    {
        if (this.state.so != null) {
        
             
            var url = process.env.REACT_APP_APIURL + "reqPersonalParking?username=" + this.state.so.value;
            fetch(url).then(res => res.json()).then((data) => {
                console.log("msg:");
                alert("parking added for " + this.state.so.value);
                this.setState({ so: null });
                 
                this.PopulatePDS();
                
            });
        }
    }



    handleSChange = (selectedOption) => {
        this.setState({ so: selectedOption });
        
    }


    PopulatePDS() {

        var url = process.env.REACT_APP_APIURL + "GetParkingDetails";
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ PD: data });
            console.log(data);
        });
          //fill dropdown here too
          url = process.env.REACT_APP_APIURL + "UsersWitoutSpots";
       fetch(url).then(res => res.json()).then((data) => {
           console.log(data);
           var arrNP = [];
           data.forEach(element => {
               var obj = {};
               obj.value = element;
               obj.label = element;
               arrNP.push(obj);

           });


            this.setState({ NP: arrNP });
            console.log(data);
        });
        /*this.setState({
            NP: [``
                { value: 'chocolate', label: 'Chocolate' },
                { value: 'strawberry', label: 'Strawberry' },
                { value: 'vanilla', label: 'Vanilla' }
            ]
        });*/


    }

      DisableSpot(spotID) {
        console.log("SPOT ID is " + spotID);
        var url = process.env.REACT_APP_APIURL + "disableSpot?SpotID=" + spotID;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            if (data < 0) {
                alert("Can not disable parking if spot is assigned to a tenet");

            } else {
                // refresh the grid

                this.PopulatePDS();

            }

            console.log(data);
        });
    }

    clearSpot(spotID)
    {
        console.log("SPOT ID is " + spotID);
        var url = process.env.REACT_APP_APIURL + "clearSpot?SpotID=" + spotID;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.PopulatePDS();

           

            console.log(data);
        });
    }
    addSpot = (e) => {
        console.log("add Dpoy");
        if (this.state.spotName.length > 0) {
            var url = process.env.REACT_APP_APIURL + "addSpot?SpotName=" + this.state.spotName;
            fetch(url).then(res => res.json()).then((data) => {
                console.log(data);
                this.PopulatePDS();
                alert("Parking Spot Added");
                this.setState({spotName:""})
                console.log(data);
            });
        }
    }



    _columns = [
        //{ visible:false, key: 'parkingSpaceID', name: '', fieldName: 'parkingSpaceID', minWidth: 0, maxWidth: 1, isResizable: false ,innerWidth:0, outerWidth:0 },
        { key: 'spaceNumber', name: 'Space Number', fieldName: 'spaceNumber', minWidth: 50, maxWidth: 75, isResizable: true },
        { key: 'userEmail', name: 'Email', fieldName: 'userEmail', minWidth: 75, maxWidth: 75, isResizable: true },
        { key: 'tenantName', name: 'Tenant Name', fieldName: 'tenantName', minWidth: 1, maxWidth: 160, isResizable: true },
        { key: 'restype', name: 'Type', fieldName: 'restype', minWidth: 60, maxWidth: 100, isResizable: true },
        { key: 'active', name: 'Active', fieldName: 'active', minWidth: 40, maxWidth: 50, isResizable: true },
        { key: 'parkingSpaceID', name: 'Clear Space', fieldName: 'parkingSpaceID', minWidth: 40, maxWidth: 50, isResizable: true }
        
    ];

    componentDidMount() {
        this.PopulatePDS();
    }
    handleChange(evt) {
        this.setState({
          [evt.target.name]: evt.target.value
        });
    
      }

    render() {

        return (
            <div >
                <div><h4>Parking Management</h4></div> 
                <div class="row"> 
                <div className="col pmBorder">
                    Add a new parking space to the Apartment Complex.<br/>
                    Space Number:&nbsp;<input type="text" name="spotName"  onChange={this.handleChange} ></input>
                    <button className="btn btn-primary  btn-sm" onClick={this.addSpot} >Add</button>
                </div>
                <div className="col pmBorder">
                    Set parking space for user.  
                    <Select onChange={this.handleSChange} className="pm" options={this.state.NP}></Select><button className="btn btn-primary  btn-sm" onClick={this.setParking} >Set Parking</button>
                
                </div>
                </div>
                <div className="scroll"><DetailsList
                items={this.state.PD}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
                /></div>
               
                
            
            </div>

            );

    }
       
    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {
          
           
    
          case 'requested':
            rtval = new Date(fieldContent).toLocaleDateString();
            
          break;
          //dateStarted
          case 'resolved':
            if(fieldContent===null){
              rtval = '';
            }else{ 
              rtval = new Date(fieldContent).toLocaleDateString();}
          break;
            case 'active':
                
                rtval = <div><button className="btn btn-primary  btn-sm"onClick={(e) => { e.preventDefault();  this.DisableSpot(item['parkingSpaceID']); }}>{fieldContent}</button></div>;
                
                break;
            case 'parkingSpaceID':
                if(item['tenantName'].length>0){ 
                    rtval = <div><button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault();  this.clearSpot(item['parkingSpaceID']); }}>clear</button></div>;
                }else
                {
                    rtval ='';
                }
                
                
                break;
          default:
            rtval= <span>{fieldContent}</span>;

        }
        return rtval;
      }




}