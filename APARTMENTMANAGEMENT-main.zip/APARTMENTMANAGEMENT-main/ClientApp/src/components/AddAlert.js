import React, { Component } from "react";

export default class AddAlert extends Component {
    static displayName = AddAlert.name;
    render() {
        return (
            <div>
                <h3>COMING SOON</h3>
            </div>
        );
    }
}