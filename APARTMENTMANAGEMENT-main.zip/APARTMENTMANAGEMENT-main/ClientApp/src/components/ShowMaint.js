import React, { Component } from 'react';
import { DetailsList ,mergeStyles} from '@fluentui/react';
const manStyle = mergeStyles({
   
   
    width: '100%',
    fontSize: '11px'
   
});
/*
const ReqStyle = mergeStyles({
   
  color:'red',
   width: '100%',
   fontSize: '11px'
  
});
const ResStyle = mergeStyles({
   
   
   width: '100%',
   fontSize: '10px'
  
});
const DateReq = mergeStyles({
   
   
   width: '1px',
   fontSize: '11px'
  
});
const DateResp = mergeStyles({
   
   
   width: '1px',
   fontSize: '11px'
  
});

*/


export class ShowMaint extends Component {
    static displayName = ShowMaint.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
      }
      
        this.PopulateManQueue = this.PopulateManQueue.bind(this);
  }
  


    _columns = [
      
      { className: manStyle,key: 'handlerName', name: 'Manager', fieldName: 'handlerName', minWidth: 80, maxWidth: 75, isResizable: true },
        { className: manStyle,key: 'requestMessage', name: 'Request', fieldName: 'requestMessage', minWidth: 100, maxWidth: 170, isResizable: true },
        { className: manStyle,key: 'responseMessage', name: 'Response', fieldName: 'responseMessage', minWidth: 100, maxWidth: 170, isResizable: true },
        { className: manStyle,key: 'requested', name: 'Requested', fieldName: 'requested', minWidth: 50, maxWidth: 100, isResizable: true },
        { className: manStyle,key: 'resolved', name: 'Date Resolved', fieldName: 'resolved', minWidth: 50, maxWidth: 100, isResizable: true }
    ];
    componentDidMount() {


      this.PopulateManQueue();
      
    }



    render() {

        return ( 
            <DetailsList 
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />



         );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {
          
    
    
          case 'requested':
            rtval = new Date(fieldContent).toLocaleDateString();
            
          break;
          //dateStarted
          case 'resolved':
            if(fieldContent===null){
              rtval = '';
            }else{ 
              rtval = new Date(fieldContent).toLocaleDateString();}
          break;
           
    
          default:
            rtval= <span>{fieldContent}</span>;

        }
        return rtval;
      }

    PopulateManQueue() {
        var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "GetUserRequests?userId=" + userId;
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ManagedItems: data });
            console.log(data);
        });

    }


}