import React, { Component } from 'react';
import { DetailsList } from '@fluentui/react';

export class ManagerReqC extends Component {
    static displayName = ManagerReqC.name;
    constructor(props) {
        super(props);
        this.state =
        {
          ManagedItems: "",
          checked:true
        }
      this.PopulateManQueue = this.PopulateManQueue.bind(this);
      this.handleInputChange = this.handleInputChange.bind(this);
  }
  handleInputChange(event) {
    this.setState({ checked: event.target.checked });
    this.PopulateManQueue(event.target.checked);
  }
    _columns = [
        { key: 'requestorID', name: 'Requestor', fieldName: 'requestorID', minWidth: 50, maxWidth: 75, isResizable: true },
        { key: 'handlerName', name: 'Manager', fieldName: 'handlerName', minWidth: 50, maxWidth: 75, isResizable: true },
        { key: 'requestMessage', name: 'Request', fieldName: 'requestMessage', minWidth: 100, maxWidth: 200, isResizable: true },
        { key: 'responseMessage', name: 'Response', fieldName: 'responseMessage', minWidth: 100, maxWidth: 200, isResizable: true },
        { key: 'requested', name: 'Date Requested', fieldName: 'requested', minWidth: 50, maxWidth: 100, isResizable: true },
        { key: 'resolved', name: 'Date Resolved', fieldName: 'resolved', minWidth: 50, maxWidth: 100, isResizable: true }
    ];
    componentDidMount() {


      this.PopulateManQueue(true);
      
    }



    render() {
      var msg = "All Requests for system";
      if (!this.state.checked) {
        msg = "Requests for " + this.props.AuthTkn.firstName + ' ' + this.props.AuthTkn.lastName;
      }
      return (<div>
          <div><h3>Completed Management Requests</h3></div>
         < div class="checkbox">
          <label><input type="checkbox"
            onChange={this.handleInputChange}
              checked={this.state.checked}
              
            name="AllReq" id="AllReq"
              />All Requests</label>
 </div>
        <div>{ msg}</div>
          
            <DetailsList 
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />

</div>

         );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {
          
    
    
          case 'requested':
            rtval = new Date(fieldContent).toLocaleDateString();
            
          break;
          //dateStarted
          case 'resolved':
            if(fieldContent===null){
              rtval = '';
            }else{ 
              rtval = new Date(fieldContent).toLocaleDateString();}
          break;
           
    
          default:
            rtval= <span>{fieldContent}</span>;

        }
        return rtval;
      }





    PopulateManQueue(all) {
      var managerId = this.props.AuthTkn.emailAddress;
      if (all === true) {
        managerId = "";
      }
      var url = process.env.REACT_APP_APIURL + "GetManagementRequests?managerId=" + managerId;
      if (this.props.PastWork ) {
        url = process.env.REACT_APP_APIURL + "GetClosedRequests?managerId=" + managerId;
      }
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ManagedItems: data });
            console.log(data);
        });

    }


}