import React, { Component } from 'react';

import   CreateNewEvent   from './CreateNewEvent';
import UpdateProfileAdmin from './UpdateProfileAdmin';
import { RegisterUser } from './RegisterUser';
import { TenantInfo } from './TenantInfo';
import { StaffInfo } from './StaffInfo';
import { ViewBookingRequests } from './ViewBookingRequests';
import  ViewAllComplaints  from './ViewAllComplaints';
import { GetAllMaintReq } from './GetAllMaintReq';
import CreateAdminAnnouncements from './CreateAdminAnnouncements';
import { BookableAreas } from './BookableAreas';
import ViewGuestDetails from './ViewGuestDetails';
export class AdminDash extends Component {
    static displayName = AdminDash.name;
    constructor(props) {
        super(props);
        this.state =
        {
            activity: <div>Welcome {this.props.AuthTkn.firstName}</div>
        }
        this.CreateNewEventF = this.CreateNewEventF.bind(this);
        this.UpdateProfile = this.UpdateProfile.bind(this);
        this.CreateNewAnnouncement = this.CreateNewAnnouncement.bind(this);
        this.RegisterUser = this.RegisterUser.bind(this);
        this.TenantInfo = this.TenantInfo.bind(this);
        this.StaffInfo = this.StaffInfo.bind(this);
        this.ViewBookingRequests = this.ViewBookingRequests.bind(this);
        this.ManBookAreas =   this.ManBookAreas.bind(this);
        this.ViewAllComplaints = this.ViewAllComplaints.bind(this);
        this.GetAllMaintReq = this.GetAllMaintReq.bind(this);
        this.GoToViewGuestDetails = this.GoToViewGuestDetails.bind(this);
    }
    CreateNewEventF() {
        var mr = <CreateNewEvent AuthTkn={this.props.AuthTkn}   ></CreateNewEvent>
        this.setState({
            activity: mr

        });
    }
    UpdateProfile() {
        var mr = <UpdateProfileAdmin AuthTkn={this.props.AuthTkn}   ></UpdateProfileAdmin>
        this.setState({
            activity: mr

        });
    }

    GoToViewGuestDetails() {
        var mr = <ViewGuestDetails AuthTkn={this.props.AuthTkn}   ></ViewGuestDetails>
        this.setState({
            activity: mr

        });
    }
    CreateNewAnnouncement() {
        var mr = <CreateAdminAnnouncements AuthTkn={this.props.AuthTkn}   ></CreateAdminAnnouncements>
        this.setState({
            activity: mr

        });
    }
    RegisterUser() {
        var mr = <RegisterUser AuthTkn={this.props.AuthTkn} ></RegisterUser>
        this.setState({
            activity: mr

        });
    }

    TenantInfo() {
        var mr = <TenantInfo AuthTkn={this.props.AuthTkn} ></TenantInfo>
        this.setState({
            activity: mr

        });
    }

    StaffInfo() {
        var mr = <StaffInfo AuthTkn={this.props.AuthTkn} ></StaffInfo>
        this.setState({
            activity: mr

        });
    }



    ViewBookingRequests() {
        var mr = <ViewBookingRequests AuthTkn={this.props.AuthTkn} ></ViewBookingRequests>
        this.setState({
            activity: mr

        });
    }
    ViewAllComplaints() {
        var mr = <ViewAllComplaints AuthTkn={this.props.AuthTkn} ></ViewAllComplaints>
        this.setState({
            activity: mr

        });
    }
    GetAllMaintReq() {
        var mr = <GetAllMaintReq AuthTkn={this.props.AuthTkn} ></GetAllMaintReq>
        this.setState({
            activity: mr

        });
    }
    ManBookAreas(){
        var mr = <BookableAreas AuthTkn={this.props.AuthTkn} ></BookableAreas>
        this.setState({
            activity: mr

        });
    }




    render() {
        let FullName = this.props.AuthTkn.firstName + ' ' + this.props.AuthTkn.lastName;
        return (
           <div>
                <nav className="navbar navbar-expand-lg navbar-light fixed-top">
                    <div className="container">
                        <div className="container text-center" >
                            <h1 style={{ color: 'white', fontSize: '24px' }}>Welcome {FullName}</h1>
                        </div>
                        <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
                            <ul className="navbar-nav ml-auto" style={{ liststyletype: 'none' }}>
                                
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.CreateNewEventF}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">Post Event</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.CreateNewAnnouncement}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">Create Announcement</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.StaffInfo}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">View/Add Staff</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.TenantInfo}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">View/Add Tenants</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.ViewBookingRequests}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">View Booking Requests</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.ManBookAreas}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">Manage Booking Areas</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.ViewAllComplaints}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">View Complaints</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.GetAllMaintReq}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">View All Maintenance Requests</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.GoToViewGuestDetails}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">View Guest Details</h6></button>
                                </li>
                                <li className="nav-item">
                                    <button className="btn btn-sm nav-link" onClick={this.UpdateProfile}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">Update Profile</h6></button>
                                </li>
                                <li className="nav-item">
                                    <a href="https://apartmentmanagerse3.azurewebsites.net/"><button className="btn btn-sm nav-link"><h6 style={{ color: 'white', fontSize: '11px' }}>Log Out</h6></button></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div style={{ width: '100%' }}   >

                    {this.state.activity}

                </div>
           </div>
        );
    }
}