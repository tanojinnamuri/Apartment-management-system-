import React, { Component } from 'react';
import  UpdateProfileSecurity   from './UpdateProfileSecurity';
import   AddAlert   from './AddAlert'; 
import Parking from './Parking';
import ParkingNT from './ParkingNT';
import AddGuestDetails from './AddGuestDetails';
import ViewGuestDetails from './ViewGuestDetails';
import CreateSecurityAnnouncements from './CreateSecurityAnnouncements';

export class SecDash extends Component {
    static displayName = SecDash.name;
    constructor(props) {
        super(props);
        this.state =
        {
            activity: <div>Welcome {this.props.AuthTkn.firstName}</div>
        }
        this.CreateNewAnnouncement = this.CreateNewAnnouncement.bind(this);
        this.GoToNewAlert = this.GoToNewAlert.bind(this);
        this.GoToProfile = this.GoToProfile.bind(this);
        this.GoToParking = this.GoToParking.bind(this);
        this.GoToParkingNT = this.GoToParkingNT.bind(this);
        this.GoToAddGuestDetails = this.GoToAddGuestDetails.bind(this);
        this.GoToViewGuestDetails = this.GoToViewGuestDetails.bind(this);
    }
    GoToViewGuestDetails() {
        var mr = <ViewGuestDetails AuthTkn={this.props.AuthTkn}   ></ViewGuestDetails>
        this.setState({
            activity: mr

        });
    }
    GoToAddGuestDetails() {
        var mr = <AddGuestDetails AuthTkn={this.props.AuthTkn}   ></AddGuestDetails>
        this.setState({
            activity: mr

        });
    }
    GoToProfile() {
        var mr = <UpdateProfileSecurity AuthTkn={this.props.AuthTkn}   ></UpdateProfileSecurity>
        this.setState({
          activity: mr
    
        });
    }
    GoToNewAlert() {
        var mr = <AddAlert AuthTkn={this.props.AuthTkn}  ></AddAlert>
        this.setState({
          activity: mr
    
        });
    }
    GoToParking() {
        var mr = <Parking AuthTkn={this.props.AuthTkn}  ></Parking>
        this.setState({
          activity: mr
    
        });
  }
  CreateNewAnnouncement() {
    var mr = <CreateSecurityAnnouncements AuthTkn={this.props.AuthTkn}   ></CreateSecurityAnnouncements>
    this.setState({
        activity: mr

    });
  }
  
  GoToParkingNT() {
    var mr = <ParkingNT AuthTkn={this.props.AuthTkn}  ></ParkingNT>
    this.setState({
      activity: mr

    });
}

    render() {
        let FullName = this.props.AuthTkn.firstName + ' ' + this.props.AuthTkn.lastName;
        return (<div><nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <div className="container text-center" >
              <h1 style={{ color: 'white' }}>Security Staff Name:{FullName}</h1>
            </div>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto" style={{ liststyletype: 'none' }}>
    
                
                <li className="nav-item">
                  <button className="btn btn-sm nav-link" onClick={this.CreateNewAnnouncement}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Create Announcement</h6></button>
                </li>
    
          
                <li className="nav-item">
                  <button className="btn btn-sm nav-link" onClick={this.GoToParkingNT}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right"> Parking</h6></button>
    
                </li>
                <li className="nav-item">
                  <button className="btn btn-sm nav-link" onClick={this.GoToAddGuestDetails}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Add Guest Details</h6></button>
                </li>
                <li className="nav-item">
                  <button className="btn btn-sm nav-link" onClick={this.GoToViewGuestDetails}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">View Guest Details</h6></button>
                </li>
                <li className="nav-item">
                  <button className="btn btn-sm nav-link" onClick={this.GoToProfile}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Update Profile</h6></button>
                </li>
                <li className="nav-item">
                  <a href="https://apartmentmanagerse3.azurewebsites.net/"><button className="btn btn-sm nav-link"><h6 style={{ color: 'white', fontSize: '11px' }}>Log Out</h6></button></a>
                </li>
    
              </ul>
            </div>
    
          </div>
        </nav>
         
    
          <div style={{ width: '100%' }} >{this.state.activity} </div>
    
          
        </div>);
      }
}