import React, { Component } from "react";
import { DetailsList } from '@fluentui/react';

export class BookableAreas extends Component {
    static displayName = BookableAreas.name;
  constructor(props) {
    super(props);
    this.state =
    {
      
      PD: [],
      MaxAttendance:0
    }
    this._renderItemColumn     = this._renderItemColumn.bind(this);
    this.DisableReservableArea = this.DisableReservableArea.bind(this);
    this.PopulatePDS           = this.PopulatePDS.bind(this);
    this.addArea               = this.addArea.bind(this);
    this.handleChange          = this.handleChange.bind(this);
  }
  addArea() {
    var name = this.state.AreaName;
    var desc = this.state.AreaDesc;
    var IsValidInt = false;
    IsValidInt = Number.isInteger(+this.state.MaxAttendance);
    var url = process.env.REACT_APP_APIURL + `AddReservableArea?MaxAttendance=${this.state.MaxAttendance}&name=${name}&Description=${desc}`;//ReservableAreaID=" + ReservableAreaID;
    console.log(url);
    if (IsValidInt) {
      fetch(url).then(res => res.json()).then((data) => {
        console.log(data);
        this.PopulatePDS();
      });
    } else { alert("Please enter a valid number for max occupancy");}
  }

  DisableReservableArea(ReservableAreaID) {
    console.log("SPOT ID is " + ReservableAreaID);
    var url = process.env.REACT_APP_APIURL + "DisableReservableArea?ReservableAreaID=" + ReservableAreaID;
    console.log(url);
    fetch(url).then(res => res.json()).then((data) => {
        console.log(data);
        
            
            // refresh the grid

            this.PopulatePDS();

        

         
    });
}

    
  handleChange(evt) {
    this.setState({
      [evt.target.name]: evt.target.value
    });

  }
  componentDidMount() {
     
    this.PopulatePDS();

  }
  PopulatePDS() {

    var url = process.env.REACT_APP_APIURL + "getReservableAreasAll";
    fetch(url).then(res => res.json()).then((data) => {
        console.log(data);
        this.setState({ PD: data });
        console.log(data);
    });
}
    
    
    
    
    
    
    
    render() {
        return (
            <div >
            <div><h4>Bookable Area  Management</h4>
            <div className="col pmBorder">
                    Add new reservable area to system<br/>
                Area Name:&nbsp;<input type="text" name="AreaName" onChange={this.handleChange} ></input>
                Description:&nbsp;<input type="text" name="AreaDesc" onChange={this.handleChange} ></input><br />
                Max Attendance: <input type="text" style={{ width: 40 }} name="MaxAttendance"   onChange={this.handleChange} />
                    <button className="btn btn-primary  btn-sm" onClick={this.addArea} >Add</button>
                </div>
            
            </div>
                <div className="scroll"><DetailsList
                items={this.state.PD}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
                /></div>
            </div>
            
        );
    }
     
    
    _columns = [
        { key: 'reservableAreaID', name: 'ID', fieldName: 'reservableAreaID', minWidth: 25, maxWidth: 50, isResizable: true },
        { key: 'name', name: 'Name', fieldName: 'name', minWidth: 25, maxWidth: 50, isResizable: true },
        { key: 'maxAttendance', name: 'Max Occupancy', fieldName: 'maxAttendance', minWidth: 1, maxWidth: 30, isResizable: true },  
      { key: 'description', name: 'Description', fieldName: 'description', minWidth: 25, maxWidth: 50, isResizable: true },
        { key: 'active', name: 'Active', fieldName: 'active', minWidth: 1, maxWidth: 100, isResizable: true },
        ];


      _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        switch (column.key) {
          case 'reservableAreaID':
            rtval = fieldContent;
            break;
          case 'name':
            rtval = fieldContent;
            break;
          case 'description':
            

            rtval = fieldContent;
            break;
          case 'active':
            var txt = 'active';
            console.log("FC");
            console.log(fieldContent);
            console.log("ENDFC")
            if (fieldContent=== false)
                txt = "Not Active";
           rtval = <div><button className="btn btn-primary  btn-sm"onClick={(e) => { e.preventDefault();  this.DisableReservableArea(item['reservableAreaID']); }}>{txt}</button></div>;
            break;
          default:
            rtval= <span>{fieldContent}</span>;
        }
        return rtval;
      }
    






}