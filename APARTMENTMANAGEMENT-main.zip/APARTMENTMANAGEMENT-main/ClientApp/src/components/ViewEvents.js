import React, { Component } from 'react';
import { DetailsList, mergeStyles } from '@fluentui/react';
const manStyle = mergeStyles({


    width: '100%',
    fontSize: '11px'

});

export class ViewEvents extends Component {
    static displayName = ViewEvents.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
        }

        this.PopulateManQueue = this.PopulateManQueue.bind(this);
    }



    _columns = [

        { ClassName: manStyle, key: 'event_Name', name: 'Name of Event', fieldName: 'event_Name', minWidth: 150, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'event_Description', name: 'Description', fieldName: 'event_Description', minWidth: 400, maxWidth: 75, isResizable: true },
        { className: manStyle, key: 'event_Date', name: 'Date', fieldName: 'event_Date', minWidth: 50, maxWidth: 170, isResizable: true },
        { className: manStyle, key: 'event_Location', name: 'Location', fieldName: 'event_Location', minWidth: 60, maxWidth: 170, isResizable: true }

    ];
    componentDidMount() {


        this.PopulateManQueue();

    }  



    render() {

        return (
            <DetailsList
                items={this.state.ManagedItems}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
            />



        );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
        rtval = <span>{fieldContent}</span>;
        return rtval;
    }

    PopulateManQueue() {
        //var userId = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "GetAllEvents";
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({   ManagedItems: data  });
            console.log(data);
        });

    }


}