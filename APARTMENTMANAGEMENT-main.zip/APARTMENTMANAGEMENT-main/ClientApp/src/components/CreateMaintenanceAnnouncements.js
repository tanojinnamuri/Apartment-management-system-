import React, { Component } from "react";

export default  class CreateMaintenanceAnnouncements extends Component {
    static displayName = CreateMaintenanceAnnouncements.name;
    constructor(props) {
        super(props);
        this.state = {
            AnnouncementType: "",
            AnnouncementText:"",
            AnnouncementDate: "",
            AnnouncementPriority: ""
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(evt) {
        this.setState({
            [evt.target.name]: evt.target.value
        });

    }

    CreateAnnouncement = (e) => {
        e.preventDefault();
        let ReqInfo = {
            a_text: this.state.AnnouncementText,
            a_date: this.state.AnnouncementDate,
            a_priority: this.state.AnnouncementPriority,
            a_type: "Maintenance"

        };


        fetch(process.env.REACT_APP_APIURL + 'AddAdminAnnouncement', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(ReqInfo)
        }).then(r => r.json()).then(res => {
            console.log(res);
            if (res) {
                if (res === -1) {
                    alert("Failed to post an announcement ");
                    this.setState({ added: false, Problem: "Failed to post an announcement " });
                }
                else {
                    this.setState({ added: true, Problem: "", TicketID: res });

                }
            } else {
                this.setState({ added: false, Problem: "Failed to post an announcement 4" });
            }
        });

    }
    render() {

        if (this.state.added){
            return(<div>Announcement is successfully posted </div>);
        }
        return (
            <div className="col">
                <form>
                    <h3>Announce Maintenance Schedule</h3>
                    
                    <div className="form-group">
                        <label> Announcement Date</label>
                        <input type="date" name="AnnouncementDate" className="form-control" placeholder="Enter Maintenance Date" onChange={this.handleChange} />
                    </div>

                    <div className="form-group">
                        <label> Priority</label>
                        
                        <select name="AnnouncementPriority" className="form-control" placeholder="Enter priority" onChange={this.handleChange} >
                             <option value="None">None</option>
                             <option value="High">High</option>
                             <option value="Medium">Medium</option>
                             <option value="Low">Low</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Announcement</label>
                        <textarea type="text" name="AnnouncementText" className="form-control" placeholder="Enter details about the maintenance" onChange={this.handleChange} />
                    </div>

                    <button type="submit" className="btn btn-primary btn-block" onClick={this.CreateAnnouncement}>Submit </button>

                </form>
                
            </div>
        );
    }
}