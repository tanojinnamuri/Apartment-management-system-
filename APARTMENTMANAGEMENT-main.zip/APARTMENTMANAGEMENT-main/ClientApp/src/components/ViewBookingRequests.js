import React, { Component } from "react";
import { DetailsList } from '@fluentui/react';
//import Select from 'react-select'
export class ViewBookingRequests extends Component {
    static displayName = ViewBookingRequests.name;
  constructor(props) {
    super(props);
    this.state =
    {
      //startDate: new Date(),
      //endDate: new Date(),
      //ReservableAreaID: 0,
      //notes: "",
      //RA: [] ,
      PD: [],
      PDCnt: -1,
      isActive: false,
      msg: "",
      alerts:false
      //apiResp: "",
      //so: null
    }
    //this.PopulateRAS = this.PopulateRAS.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.PopulatePDS = this.PopulatePDS.bind(this);
    this.PopulatePDSInt = this.PopulatePDSInt.bind(this);
      this.Approve = this.Approve.bind(this);
    this.Deny = this.Deny.bind(this);
    this._renderItemColumn = this._renderItemColumn.bind(this);
    this.addBookMessage = this.addBookMessage.bind(this);
    this.componentDidMount = this.componentDidMount.bind(this);
  }
    addBookMessage( message, id)
    {
      console.log("resID is " + id);
      const encodedValue = encodeURIComponent(message); 
        var url = process.env.REACT_APP_APIURL + "addBookMessage?ReservationID=" +id +`&message=${encodedValue}`;
        console.log("--" +url+"--")
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.PopulatePDS();
            console.log(data);
        });


    }

    Approve(resID) {
        console.log("resID is " + resID);
        var url = process.env.REACT_APP_APIURL + "ApproveRes?ReservationID=" + resID;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.PopulatePDS();
            console.log(data);
        });



     }
  Deny(resID) {
    console.log("resID is " + resID);
        var url = process.env.REACT_APP_APIURL + "DenyRes?ReservationID=" + resID;
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.PopulatePDS();
            console.log(data);
        });  


    }
    
  handleChange(evt) {
    console.log(evt.target.name);
    console.log(evt.target.value);
    this.setState({
      [evt.target.name]: evt.target.value
    });
    this.setState({ alerts: evt.target.checked });

  }
  componentDidMount() {
    this.interval = setInterval(this.PopulatePDSInt, (1000 * 30));
    this.PopulatePDS();
    
    //this.interval = setInterval(this.PopulateRAS, (1000 * 30));
  }
    
    
    
    
    
    
    
    
    render() {
        return (
            <div >
            <div><h4>Booking Management</h4></div>
            < div className="checkbox">
          <label><input type="checkbox"
            onChange={this.handleChange}
              checked={this.state.alerts}
              
            name="alerts" id="alerts"
              />Use Alerts</label>
 </div>
            <div className={this.state.isActive ? "alert alert-warning" : null} >{ this.state.msg}</div>
                <div className="scroll"><DetailsList
                items={this.state.PD}
                columns={this._columns}
                selectionMode={0}
                onRenderItemColumn={this._renderItemColumn}
                /></div>
            </div>
            
        );
  }
  
  PopulatePDSInt() {
    console.log("PopulatePDSInt ");
    console.log(this.state.alerts);
    if (this.state.alerts)
    {
      this.PopulatePDS();
    }
  }

  PopulatePDS() {
    
    this.setState({ isActive: false,msg:"" });
      console.log("PD COUNT");
      console.log(this.state.PD.length);
      console.log("DONECOUNT");
        var url = process.env.REACT_APP_APIURL + "getReservations"  ;
        this.setState({ PD: [] });    
    fetch(url).then(res => res.json()).then((data) => {
          console.log(data);
          var pdlinit = this.state.PDCnt;
          this.setState({ PD: data ,PDCnt:data.length});
          console.log(data);
          if (pdlinit !== -1)
          {
            if (pdlinit < this.state.PDCnt) {
              //alert("New Reservations");
              this.setState({ isActive: true, msg:"New Reservation Request" });

            }


          }
        });
      }
    
    _columns = [
        { key: 'tenantName', name: 'Tenant Information', fieldName: 'tenantName', minWidth: 25, maxWidth: 50, isResizable: true },
        //{ visible:false, key: 'parkingSpaceID', name: '', fieldName: 'parkingSpaceID', minWidth: 0, maxWidth: 1, isResizable: false ,innerWidth:0, outerWidth:0 },
        { key: 'startTime', name: 'Start Time', fieldName: 'startTime', minWidth: 25, maxWidth: 50, isResizable: true },
        { key: 'endTime', name: 'End Time', fieldName: 'endTime', minWidth: 25, maxWidth: 50, isResizable: true },
        { key: 'numAttending', name: 'Count', fieldName: 'numAttending', minWidth: 1, maxWidth: 30, isResizable: true },
        { key: 'notes', name: 'Notes', fieldName: 'notes', minWidth: 1, maxWidth: 100, isResizable: true },
        { key: 'replyNotes', name: 'Reply', fieldName: 'replyNotes', minWidth: 100, maxWidth: 300, isResizable: true },
        { key: 'resStatus', name: 'Status', fieldName: 'resStatus', minWidth: 20, maxWidth: 40, isResizable: true },
        { key: 'resArea', name: 'Area', fieldName: 'resArea', minWidth: 20, maxWidth: 40, isResizable: true },
        { key: 'reservationID', name: 'Approve', fieldName: 'reservationID', minWidth: 40, maxWidth: 50, isResizable: true }  
      ];
  _renderItemColumn(item, index, column) {
     
      var cv;
        const fieldContent = item[column.fieldName];//as string;
        var rtval;
    switch (column.key) {
          case 'tenantName':    
              rtval = <div>{fieldContent}<br />
                email:{item['username']} <br/>
                phone:{item['phone']}
              </div>
          break;

          case 'startTime':
            rtval = <div>{new Date(fieldContent).toLocaleDateString()}<br />
              {new Date(fieldContent).toLocaleTimeString()}</div>
            break;
          case 'endTime':
            rtval = <div>{new Date(fieldContent).toLocaleDateString()}<br />
            {new Date(fieldContent).toLocaleTimeString()}</div>
            break;
          case 'notes':
            

            rtval = fieldContent;
            break;
          case 'replyNotes':
            var rva;
            this.setState({ ["m"+index]: fieldContent });
            rva =<div><textarea onChange ={(e) =>{cv=e.target.value;this.setState({ ["m"+index]: cv });     }   }   >{fieldContent}</textarea><br/>
              <button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault(); this.addBookMessage(cv, item['reservationID']);  }}>Send Message</button>
            </div>


            rtval = rva;
            break;
          case 'resStatus':
          
            rtval = fieldContent;
            break;
          case 'resArea':
            rtval = fieldContent;
            break;
          case 'reservationID':
            if(item['resStatusID']===1){ 
              rtval = <div><button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault(); console.log(this.state["m" + index]);  this.addBookMessage(this.state["m"+index], item['reservationID']); this.Approve(fieldContent); }}>Approve</button><br/>
                    <button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault(); this.Deny(fieldContent);this.addBookMessage(this.state["m" + index], item['reservationID']); }}>Deny</button>
                </div>;
            }
            else if(item['resStatusID']===2){ 
              rtval =
                <div>
                    <button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault(); this.addBookMessage(this.state["m"+index], item['reservationID']);this.Deny(fieldContent); }}>Deny</button>
                </div>;
          }else if(item['resStatusID']===3){ 
            rtval =
              <div>
                  <button className="btn btn-primary  btn-sm" onClick={(e) => { e.preventDefault(); this.addBookMessage(this.state["m"+index], item['reservationID']);this.Approve(fieldContent); }}>Approve</button>
              </div>;
          }
            
            else
            {
                rtval ='';
            }
                break;
          default:
            rtval= <span>{fieldContent}</span>;
        }
        return rtval;
      }
    






}