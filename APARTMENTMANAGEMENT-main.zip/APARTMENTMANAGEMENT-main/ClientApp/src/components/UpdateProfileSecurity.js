import React, { Component } from "react";

export default class UpdateProfileSecurity extends Component {
    static displayName = UpdateProfileSecurity.name;
    constructor(props) {
        super(props);
        this.state = {
            FirstName: "",
            LastName:"",
            TelePhoneNumber: "",
            username: this.props.AuthTkn.emailAddress
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(evt) {
        this.setState({
            [evt.target.name]: evt.target.value
        });

    }

    CreateRequest = (e) => {
        e.preventDefault();
        console.log("CR1");
        let Tenant = {
            
            
            
            firstName: this.state.FirstName,
            lastName: this.state.LastName,
            telephoneNumber:this.state.TelePhoneNumber,
            username:this.props.AuthTkn.emailAddress
        };


        fetch(process.env.REACT_APP_APIURL + 'AddUpdateTenant', {
            method: 'POST',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(Tenant)
        }).then(r => r.json()).then(res => {
            console.log(res);
            if (res) {
                console.log(res);
            } else {
                alert(this.props.AuthTkn.emailAddress + " has been updated");
            }
        });

    }
    render() {

        if (this.state.added){
            return(<div>Profile is updated </div>);
        }
        return (
            <div className="col">
                <form>
                    <h3>Update Profile</h3>
                   
                    <div className="form-group">
                        <label>First Name</label>
                        <input type="text" name="FirstName" className="form-control" placeholder="First Name" onChange={this.handleChange} />
                    </div>

                   
                    <div className="form-group">
                        <label>Last Name</label>
                        <input type="text" name="LastName" className="form-control" placeholder="Last Name" onChange={this.handleChange} />
                    </div>

                    <div className="form-group">
                        <label>telePhoneNumber</label>
                        <input type="text" name="TelePhoneNumber" className="form-control" placeholder="telephonenumber" onChange={this.handleChange} />
                    </div>

                    <button type="submit" className="btn btn-primary btn-block" onClick={this.CreateRequest}>Update</button>

                </form>
                
            </div>
        );
    }
}