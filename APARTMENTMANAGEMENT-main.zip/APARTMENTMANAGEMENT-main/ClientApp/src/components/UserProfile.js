import React, { Component } from "react";

export default class UserProfile extends Component {
    static displayName = UserProfile.name;
    render() {
        return (
            <div>
                <h3>COMING SOON</h3>
            </div>
        );
    }
}