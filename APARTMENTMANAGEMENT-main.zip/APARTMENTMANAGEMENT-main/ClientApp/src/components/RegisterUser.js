import React, { Component } from "react";

export class RegisterUser extends Component {
    render() {
        return (
            <div>
                <h3>COMING SOONER</h3>
            </div>
        );
    }
}