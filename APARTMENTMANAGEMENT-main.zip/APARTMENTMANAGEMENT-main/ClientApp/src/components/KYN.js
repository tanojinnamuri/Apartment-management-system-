import React, { Component } from 'react';
import { DetailsList, mergeStyles } from '@fluentui/react';
const manStyle = mergeStyles({


    width: '100%',
    fontSize: '11px'

});

export class KYN extends Component {
    static displayName = KYN.name;
    constructor(props) {
        super(props);
        this.state =
        {
            ManagedItems: ""
        }

        this.PopulateManQueue = this.PopulateManQueue.bind(this);
    }


    _columns = [

        { ClassName: manStyle, key: 'fullName', name: 'Name', fieldName: 'fullName', minWidth: 100, maxWidth: 200, isResizable: true },
        { className: manStyle, key: 'blockId', name: 'Block ID', fieldName: 'blockId', minWidth: 100, maxWidth: 500, isResizable: true },
        { className: manStyle, key: 'houseNo', name: 'House Number', fieldName: 'houseNo', minWidth: 200, maxWidth: 500, isResizable: true },
        { className: manStyle, key: 'phoneNumber', name: 'Phone Number', fieldName: 'phoneNumber', minWidth: 200, maxWidth: 600, isResizable: true }

    ];
    componentDidMount() {


        this.PopulateManQueue();

    }



    render() {

        return (
            <div>
                <h3>Eligible Neighbours</h3>
                <DetailsList
                    items={this.state.ManagedItems}
                    columns={this._columns}
                    selectionMode={0}
                    onRenderItemColumn={this._renderItemColumn}
                />
            </div>

        );
    }

    _renderItemColumn(item, index, column) {
        const fieldContent = item[column.fieldName];//as string;
        var rtval = <span>{fieldContent}</span>;
        return rtval;
    }

    PopulateManQueue() {
        var eMail = this.props.AuthTkn.emailAddress;
        var url = process.env.REACT_APP_APIURL + "KYN?eMail=" + eMail;
        console.log(url);
        fetch(url).then(res => res.json()).then((data) => {
            console.log(data);
            this.setState({ ManagedItems: data });
            console.log(data);
        });

    }


}