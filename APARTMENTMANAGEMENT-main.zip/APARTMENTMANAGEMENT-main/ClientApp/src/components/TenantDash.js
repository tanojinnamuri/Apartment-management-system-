
import React, { Component } from 'react';

import { MaintReq } from './MaintReq';
import { ShowMaint } from './ShowMaint';
import { ApartmentDetails } from './ApartmentDetails';
import TParking from './TParking';
import { ViewEvents } from './ViewEvents'
import { ViewAnnouncements } from './ViewAnnouncements';
import { KYN } from './KYN';
import   UpdateProfileTenant   from './UpdateProfileTenant';
import Complaints from './Complaints';
import MakeRes from './MakeRes'
export class TenantDash extends Component {
  static displayName = TenantDash.name;
  constructor(props) {
    super(props);
    this.state =
    {
      activity: <div>Welcome {this.props.AuthTkn.firstName}</div>
    }
    this.GoToMaint = this.GoToMaint.bind(this);
    this.ApartmentDetails = this.ApartmentDetails.bind(this);
    this.ShowMaint = this.ShowMaint.bind(this);
    this.UpdateProfile = this.UpdateProfile.bind(this);
    this.ViewEvents = this.ViewEvents.bind(this);
    this.Complaints = this.Complaints.bind(this);
    this.ViewAnnouncements = this.ViewAnnouncements.bind(this);
    this.Parking = this.Parking.bind(this);
    this.KYN = this.KYN.bind(this);
    this.Res = this.Res.bind(this);
  }
  GoToMaint() {
    var mr = <MaintReq AuthTkn={this.props.AuthTkn} ></MaintReq>
    this.setState({
      activity: mr

    });
  }
  ShowMaint() {
    var mr = <ShowMaint AuthTkn={this.props.AuthTkn} ></ShowMaint>
    this.setState({
      activity: mr
    });
  }
  ApartmentDetails() {
    var mr = <ApartmentDetails AuthTkn={this.props.AuthTkn} ></ApartmentDetails>
    this.setState({
      activity: mr

    });
  }
  UpdateProfile() {
    var mr = <UpdateProfileTenant AuthTkn={this.props.AuthTkn} ></UpdateProfileTenant>
    this.setState({
      activity: mr

    });
  }//ViewEvents
    ViewEvents() {
        var mr = <ViewEvents AuthTkn={this.props.AuthTkn} ></ViewEvents>
    this.setState({
      activity: mr

    });
  }
  Complaints() {
    var mr = <Complaints AuthTkn={this.props.AuthTkn} ></Complaints>
    this.setState({
      activity: mr

    });
  }
  ViewAnnouncements() {
    var mr = <ViewAnnouncements AuthTkn={this.props.AuthTkn} ></ViewAnnouncements>
    this.setState({
      activity: mr

    });
  }
  Parking() {
    var mr = <TParking AuthTkn={this.props.AuthTkn} ></TParking>
    this.setState({
      activity: mr

    });
  }
    KYN() {
    var mr = <KYN AuthTkn={this.props.AuthTkn} ></KYN>
    this.setState({
      activity: mr

    });
  }

  Res() {
    var mr = <MakeRes AuthTkn={this.props.AuthTkn} ></MakeRes>
    this.setState({
      activity: mr

    });
  }

  render() {
    //var startItem = <  MaintReq AuthTkn={this.state.AuthTkn} />
    /*var dashboard ;
    if(this.props.AuthTkn.userType =="1")
    {
      dashboard =<  
    }
    */
    let FullName = this.props.AuthTkn.firstName + ' ' + this.props.AuthTkn.lastName;
    return (<div><nav className="navbar navbar-expand-lg navbar-light fixed-top">
      <div className="container">
        <div className="container text-center" >
          <h1 style={{ color: 'white', fontSize: '24px' }}>Welcome {FullName}</h1>
        </div>
        <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul className="navbar-nav ml-auto" style={{ liststyletype: 'none' }}>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.GoToMaint}><h6 style={{ color: 'white', fontSize: '11px', }} className="text-right">Maintenance Request</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.ShowMaint}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">View Requests</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.ApartmentDetails}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right"> My Apartment Details</h6></button>
            </li>
            
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.ViewEvents}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">View Events</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.Complaints}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right"> Make Complaints</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.ViewAnnouncements}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">View Announcements</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.Parking}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Parking</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.KYN}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Know Your Neighbour</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.Res}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Make Reservation</h6></button>
            </li>
            <li className="nav-item">
              <button className="btn btn-sm nav-link" onClick={this.UpdateProfile}><h6 style={{ color: 'white', fontSize: '11px' }} className="text-right">Update Profile</h6></button>
            </li>
            <li className="nav-item">
              <a href="https://apartmentmanagerse3.azurewebsites.net/"><button className="btn btn-sm nav-link"><h6 style={{ color: 'white', fontSize: '11px' }}>Log Out</h6></button></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
      <div style={{ width: '100%' }}   >

        {this.state.activity}

      </div>
    </div>);
  }
}