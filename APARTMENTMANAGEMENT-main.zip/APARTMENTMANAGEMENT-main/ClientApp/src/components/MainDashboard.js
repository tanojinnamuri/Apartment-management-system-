import React, { Component } from 'react';
import { TenantDash } from './TenantDash';
import { ManDash } from './ManDash';
import { AdminDash } from './AdminDash';
import { SecDash } from './SecDash';
import{Login}      from './Login';
export class MainDashboard extends Component {
  static displayName = MainDashboard.name;
  constructor(props) {
    super(props);
    this.state =
    {
      AuthTkn: null
    };

  }
  GetAuthCB = (tkn) => {


    this.setState({ AuthTkn: tkn });

    this.render();
  }
  render() {
    if (this.state.AuthTkn == null) {
      return (<Login authfunc={this.GetAuthCB} />);

    } else {

      var dashboard;
      if (this.state.AuthTkn.userType === 1) {
        dashboard = <  TenantDash AuthTkn={this.state.AuthTkn} />
      } else if (this.state.AuthTkn.userType === 2) {
        dashboard = <  AdminDash AuthTkn={this.state.AuthTkn} />
      } else if (this.state.AuthTkn.userType === 3) {
        dashboard = <  SecDash AuthTkn={this.state.AuthTkn} />
      } else if (this.state.AuthTkn.userType === 4) {
        dashboard = <  ManDash AuthTkn={this.state.AuthTkn} />
      } else {
        alert("You shouldn't be here " + this.state.AuthTkn.userType);
        console.log("Missing type" + this.state.AuthTkn.userType);
        dashboard = <div>Error in choosing user type</div>
      }

      return dashboard;


      /*return (
        <div className="container">

          <Jumbotron >Welcome {this.state.AuthTkn.firstName} to the Apartment Management System</Jumbotron>

          <div className="row">
            <div className="col-md-1"></div>
            <div className="col-md-10">{dashboard}</div>
            <div className="col-md-1"></div>


          </div>
        </div>
      );*/
    }
  }
}
