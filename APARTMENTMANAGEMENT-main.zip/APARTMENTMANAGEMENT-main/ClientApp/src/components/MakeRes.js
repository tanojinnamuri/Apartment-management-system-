import React, { Component } from "react";
import { DetailsList } from '@fluentui/react';
//import { DetailsList } from '@fluentui/react';
import DatePicker from "react-datepicker";
import Select from 'react-select'
import "react-datepicker/dist/react-datepicker.css";
export default class MakeRes extends Component {
  static displayName = MakeRes.name;
  constructor(props) {
    super(props);
    this.state =
    {
      startDate: new Date(),
      endDate: new Date(),
      ReservableAreaID: 0,
      notes: "",
      RA: [],
      PD: [],
      apiResp: "",
      so: null,
      isActive: false,
      numAttending:0
    }
    this.PopulateRAS = this.PopulateRAS.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.PopulatePDS = this.PopulatePDS.bind(this);
    this.clearWarn = this.clearWarn.bind(this);

  }

  clearWarn() {
    this.setState({ isActive: false, apiResp: "" });

  }

  handleChange(evt) {
    this.setState({
      [evt.target.name]: evt.target.value 
    });
    this.clearWarn();
  }

  render() {

    return (<div>
      <h3>Reservation Management</h3>

      <div><h4>Make Reservation</h4>
        <div className="row">
          <div className="col">
            Start Date<DatePicker
              selected={this.state.startDate}
              showTimeSelect
              onChange={(date) => {this.setState({ startDate: date });this.clearWarn(); }}
              dateFormat="Pp"
            /></div>
          <div className="col">
            End Date<DatePicker
              selected={this.state.endDate}
              showTimeSelect
              onChange={(date) => { this.setState({ endDate: date });this.clearWarn(); }}
              dateFormat="Pp"
            /><div  className={this.state.isActive?"alert alert-warning":null} >{this.state.apiResp}</div></div>
          <div className="col">
            Message
            <textarea name="notes" onChange={this.handleChange}   ></textarea><br/>
            Number Attending: <input type="text" style={{ width: 40 }} name="numAttending"   onChange={this.handleChange} />
            <Select onChange={this.handleSChange} className="pm" options={this.state.RA}></Select>
            <button className="btn btn-primary  btn-sm" onClick={this.CreateRequest} >Make Reservation</button>
            
          </div>
        </div>
      </div>
      <div><h4>Reservations</h4>
        <div className="scroll"><DetailsList
          items={this.state.PD}
          columns={this._columns}
          selectionMode={0}
          onRenderItemColumn={this._renderItemColumn}
        /></div>
      </div>
    </div>);
  }

  componentDidMount() {
    //this.PopulatePDS();
    this.PopulateRAS();
    this.interval = setInterval(this.PopulateRAS, (1000 * 30));

  }

  CreateRequest = (e) => {
    this.clearWarn();
    e.preventDefault();
    var IsValidInt = false;
    IsValidInt = Number.isInteger(+this.state.numAttending);
    console.log("AAAAAAAAAAAAAAA");
    console.log(this.state.numAttending);
    console.log("ZZZZZZZZZZZZZZZ");
    if (IsValidInt) {
      if (this.state.so != null) {
        let ResInfo = {
          username: this.props.AuthTkn.emailAddress,
          StartTime: this.state.startDate.toJSON(),
          EndTime: this.state.endDate.toJSON(),
           
          notes: this.state.notes,
          ReservableAreaID: this.state.so.value,
          numAttending:this.state.numAttending
        };
        console.log("--CreateRequest--");
        console.log(ResInfo);
        console.log("--CreateRequest--");
        fetch(process.env.REACT_APP_APIURL + 'AddReservation', {
          method: 'POST',
          headers: { 'Content-type': 'application/json' },
          body: JSON.stringify(ResInfo)
        }).then(r => r.json()).then(res => {
          console.log(res);
          if (res) {
            this.setState({ apiResp: res, isActive: true });
            this.PopulatePDS();
          } else {
            this.setState({ apiResp: "Error in adding request.  Please try again later", isActive: true });
          }
        });
      } else {
        this.setState({ apiResp: "Please pick an area to reserve", isActive: true });

      }
    } else {
      
      this.setState({ apiResp: "Please choose a value for Number Attending", isActive: true });
    }


  }

  handleSChange = (selectedOption) => {
    this.setState({ so: selectedOption });
    this.clearWarn();
  }

  PopulateRAS() {
    var url = process.env.REACT_APP_APIURL + "getReservableAreas";
    fetch(url).then(res => res.json()).then((data) => {
      console.log(data);
      var arrRA = [];
      data.forEach(element => {
        var obj = {};
        obj.value = element.reservableAreaID;
        obj.label = element.name;
        arrRA.push(obj);
      });
      this.setState({ RA: arrRA });
      console.log(data);
      this.PopulatePDS();
    });
  }

  PopulatePDS() {
    console.log("PopulatePDS1");
    var userId = this.props.AuthTkn.emailAddress;
    var url = process.env.REACT_APP_APIURL + "getReservationsForUser?userId=" + userId;
    fetch(url).then(res => res.json()).then((data) => {
      console.log("PPPPPPPPPPPPPPPPPPPPPP");
      console.log(data);
      this.setState({ PD: data });
      console.log(data);
    });
  }

  _columns = [
    //{ visible:false, key: 'parkingSpaceID', name: '', fieldName: 'parkingSpaceID', minWidth: 0, maxWidth: 1, isResizable: false ,innerWidth:0, outerWidth:0 },
    { key: 'startTime', name: 'Start Time', fieldName: 'startTime', minWidth: 50, maxWidth: 75, isResizable: true },
    { key: 'endTime', name: 'End Time', fieldName: 'endTime', minWidth: 75, maxWidth: 75, isResizable: true },
    { key: 'numAttending', name: 'Count', fieldName: 'numAttending', minWidth: 1, maxWidth: 30, isResizable: true },
    { key: 'notes', name: 'Notes', fieldName: 'notes', minWidth: 1, maxWidth: 160, isResizable: true },
    { key: 'replyNotes', name: 'Reply', fieldName: 'replyNotes', minWidth: 60, maxWidth: 100, isResizable: true },
    { key: 'resStatus', name: 'Status', fieldName: 'resStatus', minWidth: 40, maxWidth: 50, isResizable: true },
    { key: 'resArea', name: 'Area', fieldName: 'resArea', minWidth: 40, maxWidth: 50, isResizable: true }];
  _renderItemColumn(item, index, column) {
    const fieldContent = item[column.fieldName];//as string;
    var rtval;
    switch (column.key) {
      case 'startTime':
        rtval = <div>
          {new Date(fieldContent).toLocaleDateString()}<br />
          {new Date(fieldContent).toLocaleTimeString()}  </div>
        break;
      case 'endTime':
        rtval =
          <div>
            {new Date(fieldContent).toLocaleDateString()}<br />
          {new Date(fieldContent).toLocaleTimeString()}
        </div>
        break;
      case 'notes':
        rtval = fieldContent;
        break;
      case 'replyNotes':
        rtval = fieldContent;
        break;
      case 'resStatus':
        rtval = fieldContent;
        break;
      case 'resArea':
        rtval = fieldContent;
        break;

      default:
        rtval = <span>{fieldContent}</span>;
    }
    return rtval;
  }


}