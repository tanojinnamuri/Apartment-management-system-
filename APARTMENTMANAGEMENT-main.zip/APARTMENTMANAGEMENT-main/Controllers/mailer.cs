using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;


namespace SE.Controllers
{
    class Mailer
    {
        public static string SendMsg(string to, string subject, string Msg)
        {
            string retval = String.Empty;
            try
            {
                MailMessage mailMsg = new MailMessage();
                mailMsg.To.Add(new MailAddress(to));
                mailMsg.From = new MailAddress("rdonato@albany.edu");
                mailMsg.Subject = subject;
                mailMsg.Body = Msg;

                SmtpClient smtpClient = new SmtpClient("smtp.sendgrid.net", Convert.ToInt32(587));
                System.Net.NetworkCredential credentials = new System.Net.NetworkCredential("apikey", 
                "");
                smtpClient.Credentials = credentials;

                smtpClient.Send(mailMsg);
      }
        catch (Exception ex)
      {
        retval = ex.ToString() ;
        if (ex.InnerException != null) 
        {
                    retval += " !!!!";
                    retval += ex.InnerException.ToString();


                }
                
      }



            return retval;
        }







    }





}
