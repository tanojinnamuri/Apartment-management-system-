﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SE.Controllers
{
    [ApiController]
    [Route("AM/API")]
    public class ApartmentManagerController : ControllerBase
    {
        private readonly ILogger<ApartmentManagerController> _logger;

        public IConfiguration Configuration { get; }

        public ApartmentManagerController(
            IConfiguration configuration,
            ILogger<ApartmentManagerController> logger
        )
        {
            _logger = logger;
            Configuration = configuration;
        }

        [HttpPost]
        [Route("LogInuser")]
        public UserInfo LogInuser(UserInfo userInfo)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            UserInfo ui = dr.GetUser(userInfo.emailAddress, userInfo.pwd);
            return ui;
        }

        [HttpGet]
        [Route("GetManagementRequests")]
        public IEnumerable<ManagementRequest>
        GetManagementRequests(string managerId)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetManagementRequests(managerId);
        }

        [HttpGet]
        [Route("GetTestData")]
        public IEnumerable<TestCon> GetTestData()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetTestCons();
        }

        /// <summary>
        /// Adds Maintenance request
        /// </summary>
        /// <param name="mr">Maintenance Request</param>
        /// <returns>Maintence requestID</returns>
        [HttpPost]
        [Route("AddMaintRequest")]
        public int AddMaintRequest(ManagementRequest mr)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            int rv = dr.AddMaintRequest(mr);
            return rv;
        }

        [HttpGet]
        [Route("GetUserRequests")]
        public IEnumerable<ManagementRequest> GetUserRequests(string userId)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetUserRequests(userId);
        }

        [HttpGet]
        [Route("GetClosedRequests")]
        public IEnumerable<ManagementRequest>
        GetClosedRequests(string managerId)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetClosedManagementRequests(managerId);
        }

        [HttpGet]
        [Route("GetApartmentDetails")]
        public IEnumerable<ApartmentDetails> GetApartmentDetails(string userId)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetApartmentDetails(userId);
        }

        [HttpGet]
        [Route("GetParkingDetails")]
        public IEnumerable<ParkingDetail> GetParkingDetails(string userId)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetParkingDetails();
        }

        [HttpGet]
        [Route("disableSpot")]
        public int disableSpot(int SpotID)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.disableSpot(SpotID);
        }

        [HttpGet]
        [Route("GetAllMaintReq")]
        public IEnumerable<ManagementRequest> GetAllMaintReq()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetAllMaintReq();
        }

        [Route("GetTenParkingDetails")]
        public IEnumerable<ParkingDetail> GetTenParkingDetails(string username)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetParkingDetails(username);
        }

        [Route("reqParking")]
        public JsonResult GetTenParkingreqParkingDetails(string username)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.reqParking(username));
        }

        [Route("canParking")]
        public JsonResult canParking(string username)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.canParking(username));
        }

        [HttpPost]
        [Route("AddEvent")]
        public int AddEvent(EventDetails ed)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            int rv = dr.AddEvent(ed);
            return rv;
        }

        [HttpGet]
        [Route("clearSpot")]
        public int clearSpot(int SpotID)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.clearSpot(SpotID);
        }

        [HttpGet]
        [Route("GetAllEvents")]
        public IEnumerable<EventDetails> GetAllEvents()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetAllEvents();
        }

        [HttpPost]
        [Route("AddAdminAnnouncement")]
        public int AddAdminAnnouncement(AnnouncementDetails ed)
        {
            DataRepository dr = new DataRepository(Configuration, _logger, null);
            int rv = dr.AddAdminAnnouncement(ed);
            return rv;
        }
        [HttpGet]
        [Route("UsersWitoutSpots")]
        public IEnumerable<string> UsersWitoutSpots()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.UsersWitoutSpots();
        }

        [HttpGet]
        [Route("reqPersonalParking")]
        public JsonResult reqPersonalParking(string username)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.reqPersonalParking(username));
        }

        [HttpGet]
        [Route("addSpot")]
        public JsonResult addSpot(string SpotName)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.addSpot(SpotName));
        }
        [HttpGet]
        [Route("getReservableAreas")]
        public IEnumerable<ReservableArea> getReservableAreas()
        { 
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.getReservableAreas();

        }
        /*
             
            string username, 
	        DateTime StartTime, 
	        DateTime ENdTime , 
	        string Notes,
	        int ReservableAreaID

             username, 
	         StartTime, 
	         ENdTime , 
	         Notes,
	         ReservableAreaID
        
        
        
        */
        [HttpPost]
        [Route("AddReservation")]
        public JsonResult AddReservation(Reservation res)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.AddReservation(res));
        }

        [HttpGet]
        [Route("getReservationsForUser")]
        public IEnumerable<Reservation> getReservationsForUser(string userId)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.getReservationsForUser(userId);
        }
        //public Reservation []  getReservations()    
        [HttpGet]
        [Route("getReservations")]
        public IEnumerable<Reservation> getReservations()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.getReservations( );
        }

        [HttpGet]
        [Route("ApproveRes")]
        public JsonResult ApproveRes(int ReservationID)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.ApproveRes(ReservationID));
        }

        [HttpGet]
        [Route("DenyRes")]
        public JsonResult DenyRes(int ReservationID)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.DenyRes(ReservationID));
        }


        [HttpPost]
        [Route("AddGuest")]
        public int AddGuest(GuestDetails gd)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            int rv = dr.AddGuest(gd);
            return rv;
        }

        [HttpGet]
        [Route("ViewGuestDetails")]
        public IEnumerable<GuestDetails> ViewGuestDetails()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.ViewGuestDetails();
        }
        [HttpGet]
        [Route("GetAllAnnouncements")]
        public IEnumerable<AnnouncementDetails> GetAllAnnouncements()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetAllAnnouncements();
        }

        [HttpGet]
        [Route("addBookMessage")]
        public JsonResult addBookMessage(int ReservationID, string message)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.addBookMessage(ReservationID, message));
        }
        [HttpGet]
        [Route("disableReservableArea")]
        public int disableReservableArea(int ReservableAreaID)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.disableReservableArea(ReservableAreaID);
        }

        [Route("AddReservableArea")]
        public JsonResult AddReservableArea( string Name, String Description, int MaxAttendance)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return new JsonResult(dr.AddReservableArea(   Name,   Description,MaxAttendance));
        }

        [HttpGet]
        [Route("getReservableAreasAll")]
        public IEnumerable<ReservableArea> getReservableAreasAll()
        { 
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.getReservableAreas(true);

        }

        [HttpGet]
        [Route("send")]
        public JsonResult send( )
        {
            string rv = Mailer.SendMsg("rdonato@albany.edu", "TEST", "A MESSAGE");
            return new JsonResult(rv);
        }

        [HttpGet]
        [Route("getAllTenants")]
        public IEnumerable<Tenant> getAllTenants()
        { 
            Tenant t =
                new Tenant(Configuration, _logger );
            return t.GetAllTenants();
        }

        [HttpPost]
        [Route("AddUpdateTenant")]
        public JsonResult AddUpdateTenant(Tenant ten)
        {
            Tenant t =
                new Tenant(Configuration, _logger );
            return new JsonResult(t.AddUpdateTenant(ten));
        }

        [HttpGet]
        [Route("GetTenant")]
        public  Tenant  GetTenant(string username)
        { 
            Tenant t =
                new Tenant(Configuration, _logger );
            return t.GetTenant(username);
        }
        [HttpGet]
        [Route("GetEmptyApartments")]
        public IEnumerable<ApartmentDetails> GetEmptyApartments()
        { 
             
             DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetEmptyApartments();

        }

        [HttpGet]
        [Route("getAllStaff")]
        public IEnumerable<StaffInfo> getAllStaff()
        { 
            StaffInfo t =
                new StaffInfo(Configuration, _logger );
            return t.GetAllStaff();
        }

        [HttpPost]
        [Route("AddUpdateStaff")]
        public JsonResult AddUpdateStaff(StaffInfo ten)
        {
            StaffInfo t =
                new StaffInfo(Configuration, _logger );
            return new JsonResult(t.AddUpdateStaff(ten));
        }

        [HttpPost]
        [Route("updatePwd")]
        public JsonResult updatePwd(UserInfo ui)
        {
            UserInfo t =
                new UserInfo(Configuration, _logger );
            return new JsonResult(t.updatePwd(ui));
        }


        [HttpGet]
        [Route("GetStaff")]
        public  StaffInfo  GetStaff(string username)
        { 
            StaffInfo t =
                new StaffInfo(Configuration, _logger );
            return t.GetStaff(username);
        }

         [HttpPost]
        [Route("AddComplaint")]
        public int AddComplaint(ComplaintDetails ed)
        {
            DataRepository dr = new DataRepository(Configuration, _logger, null);
            int rv = dr.AddComplaint(ed);
            return rv;
        }
        [HttpGet]
        [Route("GetAllComplaints")]
        public IEnumerable<ComplaintDetails> GetAllComplaints()
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.GetAllComplaints();
        }

        [HttpGet]
        [Route("KYN")]
        public IEnumerable<KYNdetails> KYN(string eMail)
        {
            DataRepository dr =
                new DataRepository(Configuration, _logger, null);
            return dr.KYN(eMail);
        }

        [HttpPost]
        [Route("RemoveUser")]
        public JsonResult RemoveUser(UserInfo ui)
        {
            UserInfo t =
                new UserInfo(Configuration, _logger );
            return new JsonResult(t.RemoveUser(ui.emailAddress));
        }
       

    }
}
