using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;


namespace SE.Controllers
{
    public class DataRepository
    {

        public ISession TSession { get; set; }
        public enum UserTypes { Tenant = 1, Admin, Security, Manager };
        private string _errMsg;
        private IConfiguration Configuration;
        private ILogger _logger;
        private UserInfo[] devUsers = new UserInfo[]{
            new UserInfo(){ emailAddress="rdonato@albany.edu", lastName="Donato", firstName="Ralph", userType=(int)UserTypes.Tenant, pwd=""},
            new UserInfo(){ emailAddress="xyz@albany.edu", lastName="SMITH", firstName="Mike", userType=(int)UserTypes.Manager, pwd=""},
            new UserInfo(){ emailAddress="MTS@albany.edu", lastName="Rogers", firstName="Bill", userType=(int)UserTypes.Admin, pwd=""}
        };








        public DataRepository(IConfiguration config, ILogger logger, ISession session = null)
        {
            _errMsg = string.Empty;
            Configuration = config;
            _logger = logger;
            if (session != null)
            {
                TSession = session;

            }
        }

        public UserInfo GetUser(string eMail, String Pwd)
        {
            try
            {
                using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
                {


                    String sql = "SELECT username,firstName,lastName,profilePicture,phoneNumber,u_type FROM dbo.mainTable where active =1 and username=@eMail and pw_hash=@Pwd";

                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@eMail", eMail);
                    sda.SelectCommand.Parameters.AddWithValue("@Pwd", Pwd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new UserInfo()
                             {
                                 userType = da.Field<int>("u_type"),
                                 firstName = da.Field<string>("firstName"),
                                 lastName = da.Field<string>("lastName"),
                                 phoneNumber = da.Field<string>("phoneNumber"),
                                 emailAddress = da.Field<string>("username")


                             };
                    return rv.FirstOrDefault();
                }

            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error");

                }
                return null;
            }






        }


        public ManagementRequest[] GetManagementRequests(string managerID)
        {

            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;

                    if (string.IsNullOrWhiteSpace(managerID))
                        sql = @"SELECT [MainReqID],[RequestorUN],[HandlerID]
                        ,[RequestMessage]
                        ,[ResponseMessage]
                        ,[Requested]
                        ,[Resolved]
                        FROM [dbo].[MainReq]";
                    else
                    {
                        sql = @"SELECT [MainReqID],[RequestorUN],[HandlerID]
                        ,[RequestMessage]
                        ,[ResponseMessage]
                        ,[Requested]
                        ,[Resolved]
                        FROM [dbo].[MainReq] where HandlerID =@HandlerID";



                    }
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    if (!string.IsNullOrWhiteSpace(managerID))
                    {
                        sda.SelectCommand.Parameters.AddWithValue("@HandlerID", managerID);

                    }
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ManagementRequest()
                             {

                                 requestID = da.Field<int>("MainReqID"),
                                 RequestorID = da.Field<string>("RequestorUN"),
                                 handlerName = da.Field<string>("HandlerID"),
                                 RequestMessage = da.Field<string>("RequestMessage"),
                                 ResponseMessage = da.Field<string>("ResponseMessage"),
                                 Requested = da.Field<DateTime>("Requested"),
                                 Resolved = da.Field<DateTime?>("Resolved")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetManagementRequests");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetManagementRequests");

                    }
                    return null;
                }
            }
        }

        public TestCon[] GetTestCons()
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql = "SELECT TestCon,dataone,datatwo FROM dbo.TestCon";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new TestCon()
                             {
                                 TestConID = da.Field<int>("TestCon"),
                                 dataone = da.Field<string>("dataone"),
                                 datatwo = da.Field<string>("datatwo")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error");
                    }
                    TestCon[] reval = new TestCon[]{ new TestCon(){
                        TestConID =1,
                        dataone = exp.Message,
                        datatwo = exp.ToString()

                    }};
                    return reval;
                }
            }
        }
        public int AddMaintRequest(ManagementRequest req)
        {
            int retval = -1;
            try
            {
                using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
                {


                    String sql =
                        "Insert into MainReq(RequestorUN,RequestMessage)values(@RequestorUN,@RequestMessage);Select @@identity";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.Text;
                    scmd.Parameters.AddWithValue("@RequestorUN", req.RequestorID);
                    scmd.Parameters.AddWithValue("@RequestMessage", req.RequestMessage);
                    object rvObj = scmd.ExecuteScalar();
                    retval = Convert.ToInt32(rvObj);
                }

            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "AddMaintRequest");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "AddMaintRequest");

                }
                retval = -1;
            }




            return retval;
        }



        public ManagementRequest[] GetUserRequests(string userID)
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;

                    if (string.IsNullOrWhiteSpace(userID))
                        sql = @"SELECT [MainReqID],[RequestorUN],[HandlerID]
                        ,[RequestMessage]
                        ,[ResponseMessage]
                        ,[Requested]
                        ,[Resolved]
                        FROM [dbo].[MainReq]";
                    else
                    {
                        sql = @"SELECT [MainReqID],[RequestorUN],[HandlerID]
                        ,[RequestMessage]
                        ,[ResponseMessage]
                        ,[Requested]
                        ,[Resolved]
                        FROM [dbo].[MainReq] where RequestorUN =@HandlerID";



                    }
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    if (!string.IsNullOrWhiteSpace(userID))
                    {
                        sda.SelectCommand.Parameters.AddWithValue("@HandlerID", userID);

                    }
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ManagementRequest()
                             {

                                 requestID = da.Field<int>("MainReqID"),
                                 RequestorID = da.Field<string>("RequestorUN"),
                                 handlerName = da.Field<string>("HandlerID"),
                                 RequestMessage = da.Field<string>("RequestMessage"),
                                 ResponseMessage = da.Field<string>("ResponseMessage"),
                                 Requested = da.Field<DateTime>("Requested"),
                                 Resolved = da.Field<DateTime?>("Resolved")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetUserRequests");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetUserRequests");

                    }
                    return null;
                }
            }
        }
        public ManagementRequest[] GetClosedManagementRequests(string managerID)
        {

            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {

                    SqlDataAdapter sda = new SqlDataAdapter("GetManagementClosedRequests", sconn);
                    sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                    if (!string.IsNullOrWhiteSpace(managerID))
                    {
                        sda.SelectCommand.Parameters.AddWithValue("@HandlerID", managerID);

                    }
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ManagementRequest()
                             {

                                 requestID = da.Field<int>("MainReqID"),
                                 RequestorID = da.Field<string>("RequestorUN"),
                                 handlerName = da.Field<string>("HandlerID"),
                                 RequestMessage = da.Field<string>("RequestMessage"),
                                 ResponseMessage = da.Field<string>("ResponseMessage"),
                                 Requested = da.Field<DateTime>("Requested"),
                                 Resolved = da.Field<DateTime?>("Resolved")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetManagementRequests");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetManagementRequests");

                    }
                    return null;
                }
            }
        }
        public ApartmentDetails[] GetApartmentDetails(string userID)
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql = @"SELECT TOP (1) [houseID],[username],[houseNo],[blockId] from [dbo].[ApartmentTable] where username=@HandlerID";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    if (!string.IsNullOrWhiteSpace(userID))
                    {
                        sda.SelectCommand.Parameters.AddWithValue("@HandlerID", userID);

                    }
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ApartmentDetails()
                             {
                                 houseID = da.Field<string>("houseID"),
                                 username = da.Field<string>("username"),
                                 houseNo = da.Field<int>("houseNo"),
                                 blockId = da.Field<string>("blockId")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetApartmentDetails");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetApartmentDetails");

                    }
                    return null;
                }
            }
        }
        public ParkingDetail[] GetParkingDetails(string TeneantName = "")
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql = "GetParkingInfoForUser";//""GetParkingInfo";
                    if (TeneantName.Trim().Length <= 0)
                    {
                        sql = "GetParkingInfo";
                    }
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    if (TeneantName.Trim().Length > 0)
                    {
                        // sda.SelectCommand.Parameters.AddWithValue("@username", TeneantName);
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        sda.SelectCommand.Parameters.AddWithValue("@username", TeneantName);
                    }
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ParkingDetail()
                             {
                                 SpaceNumber = da.Field<string>("SpaceNumber"),
                                 UserEmail = da.Field<string>("UserEmail"),
                                 active = da.Field<bool>("active") ? "YES" : "NO",
                                 tenantName = da.Field<string>("UserName"),
                                 buildingName = da.Field<string>("BuildingName"),
                                 parkingSpaceID = da.Field<int>("ParkingSpaceID"),
                                 Restype = da.Field<string>("Restype")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetParkingInfo");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetParkingInfo");

                    }
                    return null;
                }
            }
        }
        public int disableSpot(int spotid)
        {
            int retval = 0;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "SetSpotInactive";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@SpotID", spotid);
                    retval = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - disableSpot");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - disableSpot");

                    }
                }
            }
            return retval;
        }


        public ManagementRequest[] GetAllMaintReq()
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;
                    sql = @"SELECT [MainReqID],[RequestorUN],[HandlerID]
                        ,[RequestMessage]
                        ,[ResponseMessage]
                        ,[Requested]
                        ,[Resolved]
                        FROM [dbo].[MainReq]";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@HandlerID", "*");
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ManagementRequest()
                             {
                                 RequestorID = da.Field<string>("RequestorUN"),
                                 handlerName = da.Field<string>("HandlerID"),
                                 RequestMessage = da.Field<string>("RequestMessage"),
                                 ResponseMessage = da.Field<string>("ResponseMessage"),
                                 Requested = da.Field<DateTime>("Requested"),
                                 Resolved = da.Field<DateTime?>("Resolved")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetAllMaintRequests");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetAllMaintRequests");

                    }
                    return null;
                }
            }
        }
        public string reqParking(string TeneantName)
        {
            string rv = "No Spots available";
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "reqParking";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@username", TeneantName);
                    rv = Convert.ToString(scmd.ExecuteScalar());
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - reqParking");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - disableSpot");

                    }
                    rv = "there was a problem with your request please try later";
                }
            }
            return rv;
        }
        public int canParking(string TeneantName)
        {
            int rv = -1;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "canParking";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@username", TeneantName);
                    rv = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - canParking");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - canParking");

                    }
                    rv = -1;
                }
            }
            return rv;
        }
        public int clearSpot(int spotid)
        {
            int retval = 0;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "clearSpot";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@SpotID", spotid);
                    retval = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - clearSpot");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - clearSpot");



                    }
                }
            }
            return retval;
        }

        public int AddEvent(EventDetails req)
        {
            int retval = -1;
            try
            {
                using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
                {


                    String sql =
                        "Insert into events(event_Description,event_Date,event_Location,event_Name)values(@event_Description,@event_Date,@event_Location,@event_Name);Select @@identity";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.Text;
                    scmd.Parameters.AddWithValue("@event_Description", req.event_Description);
                    scmd.Parameters.AddWithValue("@event_Date", req.event_Date);
                    scmd.Parameters.AddWithValue("@event_Location", req.event_Location);
                    scmd.Parameters.AddWithValue("event_Name", req.event_Name);
                    object rvObj = scmd.ExecuteScalar();
                    retval = Convert.ToInt32(rvObj);
                }

            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "AddEvent");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "AddEvent");



                }
                retval = -1;
            }
            return retval;
        }
        public EventDetails[] GetAllEvents()
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;
                    sql = @"SELECT [event_Description],[event_Date],[event_Location],[event_Name]
                        FROM [dbo].[events]";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@HandlerID", "*");
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new EventDetails()
                             {
                                 event_Description = da.Field<string>("event_Description"),
                                 event_Date = da.Field<string>("event_Date"),
                                 event_Location = da.Field<string>("event_Location"),
                                 event_Name = da.Field<string>("event_Name")

                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetAllEvents");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetAllEvents");

                    }
                    return null;
                }
            }
        }

        public int addSpot(string SpaceNumber)
        {
            int rv = -1;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "addSpot";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@SpaceNumber", SpaceNumber);
                    rv = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - addSpot");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - addSpot");

                    }
                    rv = -1;
                }
            }
            return rv;
        }
        public String[] UsersWitoutSpots()
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;
                    sql = @"UsersWitoutSpots";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select

                                da.Field<string>("username")

                              ;
                    return rv.ToArray<string>();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - UsersWitoutSpots");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - UsersWitoutSpots");

                    }
                    return null;
                }
            }
        }
        public string reqPersonalParking(string TeneantName)
        {
            string rv = "No Spots available";
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "reqPersonalParking";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@username", TeneantName);
                    rv = Convert.ToString(scmd.ExecuteScalar());
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - reqPersonalParking");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - reqPersonalParking");

                    }
                    rv = "there was a problem with your request please try later";
                }
            }
            return rv;
        }
        public ReservableArea []  getReservableAreas(bool all =false )
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql;
                    sql = @"ReservableAreas";
                    if (all)
                    {
                        sql = @"AllReservableAreas";
                    }
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@HandlerID", "*");
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                        select new ReservableArea()
                        {
                            ReservableAreaID=da.Field<int>("ReservableAreaID"),
                            Name = da.Field<string>("Name"),
                            Description = da.Field<string>("Description"),
                            Active =da.Field<bool>("Active"),
                            MaxAttendance =da.Field<int>("MaxAttendance")
                        };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - getReservableAreas");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - getReservableAreas");

                    }
                    return null;
                }
            }
        }
        public string AddReservation(
            /*string username, 
	        DateTime StartTime, 
	        DateTime ENdTime , 
	        string Notes,
	        int ReservableAreaID
            */
            Reservation res
            )
        { 
            string rv = "";
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "AddReservation";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@username", res.username);
                    scmd.Parameters.AddWithValue("@StartTime", res.StartTime);
                    scmd.Parameters.AddWithValue("@ENdTime", res.EndTime);
                    scmd.Parameters.AddWithValue("@Notes", res.notes);
                    scmd.Parameters.AddWithValue("@ReservableAreaID", res.ReservableAreaID);
                    scmd.Parameters.AddWithValue("@numAttending", res.numAttending);
                    rv = Convert.ToString(scmd.ExecuteScalar());
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - AddReservation");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - AddReservation");
                    }
                    rv = "there was a problem with your request please try later";
                }
            }
            return rv;
        }
        public Reservation []  getReservationsForUser(string username)
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql;
                    sql = @"GetReservationsForTenant";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sda.SelectCommand.Parameters.AddWithValue("@username", username);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                        select new Reservation()
                        {
                            StartTime =da.Field<DateTime>("StartTime" ),
                            EndTime   =da.Field<DateTime>("EndTime"   ),
                            notes     =da.Field<String>  ("notes"     ),
                            ReplyNotes=da.Field<String>  ("ReplyNotes"),
                            ResArea   =da.Field<String>  ("Name"      ),
                            ResStatus =da.Field<String>  ("ResStat"   ),
                            numAttending = da.Field<int>  ("numAttending"   )
                        };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - getReservationsForUser");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - getReservationsForUser");

                    }
                    return null;
                }
            }
        }

        public Reservation []  getReservations()
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql;
                    sql = @"GetReservations";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                     
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                        select new Reservation()
                        {
                            StartTime       =da.Field<DateTime>("StartTime"       ),
                            EndTime         =da.Field<DateTime>("EndTime"         ),
                            notes           =da.Field<String>  ("notes"           ),
                            ReplyNotes      =da.Field<String>  ("ReplyNotes"      ),
                            ResArea         =da.Field<String>  ("Name"            ),
                            ResStatus       =da.Field<String>  ("ResStat"         ),
                            ReservationID   =da.Field<int>     ("ReservationID"   ),
                            ReservableAreaID=da.Field<int>     ("ReservableAreaID"),
                            ResStatusID     =da.Field<int>     ("ResStatusID"     ),
                            TenantName      =da.Field<string>  ("TenantName"      ),
                            username        =da.Field<string>  ("username"        ),
                            phone           =da.Field<string>  ("phone"           ),
                            numAttending    =da.Field<int>     ("numAttending"    )
                        };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - getReservations");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - getReservations");

                    }
                    return null;
                }
            }
        }
        public int ApproveRes(int  ReservationID)
        {
            int retval = 0;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql = "ApproveRes";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@ReservationID",  ReservationID);
                    retval = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - ApproveRes");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - ApproveRes");
                    }
                }
            }
            return retval;
        }

        public int DenyRes(int  ReservationID)
        {
            int retval = 0;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql = "DenyRes";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@ReservationID",  ReservationID);
                    retval = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - DenyRes");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - DenyRes");
                    }
                }
            }
            return retval;
        }


        public int AddGuest(GuestDetails req)
        {
            int retval = -1;
            try
            {
                using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
                {
                    String sql =
                        "Insert into guestDetailsTable(guest_Name,block_Id,house_No,guest_Number,entry_Date)values(@guest_Name,@block_Id,@house_No,@guest_Number,@entry_Date);Select @@identity";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.Text;
                    scmd.Parameters.AddWithValue("@guest_Name", req.guest_Name);
                    scmd.Parameters.AddWithValue("@entry_Date", DateTime.Now);
                    scmd.Parameters.AddWithValue("@block_Id", req.block_Id);
                    scmd.Parameters.AddWithValue("@house_No", req.house_No);
                    scmd.Parameters.AddWithValue("@guest_Number", req.guest_Number);
                    object rvObj = scmd.ExecuteScalar();
                    retval = Convert.ToInt32(rvObj);
                }

            }
            catch (Exception exp)
            {

                _logger.LogError(exp, "AddGuest");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "AddGuest");

                }
                retval = -1;
            }
            return retval;
        }


        
        public GuestDetails[] ViewGuestDetails()
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;
                    sql = @"SELECT [guest_Name],[entry_Date],[block_Id],[house_No],[guest_Number] FROM [dbo].[guestDetailsTable]";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new GuestDetails()
                             {
                                 guest_Name = da.Field<string>("guest_Name"),
                                 entry_Date = da.Field<DateTime>("entry_Date"),
                                 block_Id = da.Field<string>("block_Id"),
                                 house_No = da.Field<string>("house_No"),
                                 guest_Number = da.Field<string>("guest_Number")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - ViewGuestDetails");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - ViewGuestDetails");

                    }
                    return null;
                }
            }
        }
          
        public int AddAdminAnnouncement(AnnouncementDetails req)
        {
            int retval = -1;
                        try
            {
                using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
                {

                     

                    String sql =
                        "Insert into announcement(a_type,a_date,a_text,a_priority)values(@a_type,@a_date,@a_text,@a_priority);Select @@identity";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.Text;
                    scmd.Parameters.AddWithValue("@a_type", req.a_type);
                    scmd.Parameters.AddWithValue("@a_date", req.a_date);
                    scmd.Parameters.AddWithValue("@a_text", req.a_text);
                    scmd.Parameters.AddWithValue("@a_priority", req.a_priority);
                    object rvObj = scmd.ExecuteScalar();
                    retval = Convert.ToInt32(rvObj);
                }

            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "AddAdminAnnouncement");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "AddAdminAnnouncement");


         
                }
                retval = -1;
            }
            return retval;
        }
        public int addBookMessage(int  ReservationID, string message)
        {
            int retval = 0;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql = "addBookMessage";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@ReservationID",  ReservationID);
                    scmd.Parameters.AddWithValue("@message",  message);
                    retval = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - addBookMessage");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - addBookMessage");
                    }
                }
            }
            return retval;
        }

        public string AddReservableArea(  string Name, String Description, int MaxAttendance)
        { 
            string rv = "";
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "AddReservableArea";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@Name", Name);
                    scmd.Parameters.AddWithValue("@Description", Description);
                    scmd.Parameters.AddWithValue("@MaxAttendance", MaxAttendance);
                    rv = Convert.ToString(scmd.ExecuteScalar());
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - AddReservableArea");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - AddReservableArea");
                    }
                    rv = "there was a problem adding the Reservable area";
                }
            }
            return rv;
        }

        public int disableReservableArea(int ReservableAreaID)
        {
            int retval = 0;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql =
                        "DisableReservableArea";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@ReservableAreaID", ReservableAreaID);
                    retval = scmd.ExecuteNonQuery();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - disableReservableArea");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - disableReservableArea");

                    }
                }
            }
            return retval;
        }










         public AnnouncementDetails[] GetAllAnnouncements()
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;
                    sql = @"SELECT [a_priority],[a_text],[a_type],[a_date]
                        FROM [dbo].[announcement]";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@HandlerID", "*");
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new AnnouncementDetails()
                             {
                                 a_type = da.Field<string>("a_type"),
                                 a_date = da.Field<DateTime>("a_date"),
                                 a_text = da.Field<string>("a_text"),
                                 a_priority = da.Field<string>("a_priority")

                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetAllAnnouncements");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetAllAnnouncements");

                    }
                    return null;
                }
            }
        }
        public ApartmentDetails[] GetEmptyApartments()
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                try
                {
                    String sql = @"EmptyApartments";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ApartmentDetails()
                             {
                                 houseID = da.Field<string>("houseID"),
                                 houseNo = da.Field<int>("houseNo"),
                                 blockId = da.Field<string>("blockId")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetEmptyApartments");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetEmptyApartments");

                    }
                    return null;
                }
            }
        }
        public int AddComplaint(ComplaintDetails req)
        {
            int retval = -1;
          try
            {
                using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
                {

                    var url = GetApartmentDetails(req.c_requestor);
                  

                    String sql =
                        "Insert into Complaint(c_type,c_date,c_text,c_priority,c_requestor,c_houseNo,c_blockId)values(@c_type,@c_date,@c_text,@c_priority,@c_requestor,@c_houseNo,@c_blockId);Select @@identity";
                    sconn.Open();
                    SqlCommand scmd = sconn.CreateCommand();
                    scmd.CommandText = sql;
                    scmd.CommandType = CommandType.Text;
                    scmd.Parameters.AddWithValue("@c_type", req.c_type);
                    scmd.Parameters.AddWithValue("@c_date", req.c_date);
                    scmd.Parameters.AddWithValue("@c_text", req.c_text);
                    scmd.Parameters.AddWithValue("@c_priority", req.c_priority);
                    scmd.Parameters.AddWithValue("@c_requestor", req.c_requestor);
                    scmd.Parameters.AddWithValue("@c_houseNo", url[0].houseNo);
                    scmd.Parameters.AddWithValue("@c_blockId", url[0].blockId);
                    object rvObj = scmd.ExecuteScalar();
                    retval = Convert.ToInt32(rvObj);
                }

            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "AddComplaint");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "AddComplaint");


         
                }
                retval = -1;
          }
            return retval;
        }
         public ComplaintDetails[] GetAllComplaints()
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql;
                    sql = @"SELECT [c_priority],[c_text],[c_type],[c_date],[c_requestor],[c_houseNo],[c_blockId]
                        FROM [dbo].[Complaint]";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@HandlerID", "*");
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new ComplaintDetails()
                             {
                                 c_type = da.Field<string>("c_type"),
                                 c_date = da.Field<DateTime>("c_date"),
                                 c_text = da.Field<string>("c_text"),
                                 c_priority = da.Field<string>("c_priority"),
                                 c_requestor = da.Field<string>("c_requestor"),
                                 c_houseNo = da.Field<int>("c_houseNo"),
                                 c_blockId = da.Field<string>("c_blockId")

                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - GetAllComplaints");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - GetAllComplaints");

                    }
                    return null;
                }
            }
        }



        public KYNdetails[] KYN(string eMail)
        {
            //userID = string.Empty;
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {

                try
                {
                    String sql = "SELECT firstName,lastName,houseNo,blockId,phoneNumber FROM dbo.mainTable,dbo.ApartmentTable where dbo.ApartmentTable.username=dbo.mainTable.username AND ApartmentTable.username<>@eMail AND dbo.ApartmentTable.blockId=(select blockId from dbo.ApartmentTable where username=@eMail)";
                    SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                    sda.SelectCommand.Parameters.AddWithValue("@eMail", eMail);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    var rv = from da in dt.AsEnumerable()
                             select new KYNdetails()
                             {

                                 //firstName = da.Field<string>("firstName"),
                                 //lastName = da.Field<string>("lastName"),
                                 blockId = da.Field<string>("blockId"),
                                 houseNo = da.Field<int>("houseNo"),
                                 phoneNumber = da.Field<string>("phoneNumber"),
                                 fullName = da.Field<string>("firstName")+' '+da.Field<string>("lastName")
                             };
                    return rv.ToArray();
                }
                catch (Exception exp)
                {
                    _logger.LogError(exp, "Error - KYN");
                    if (exp.InnerException != null)
                    {
                        _logger.LogError(exp.InnerException, "Error - KYN");

                    }
                    return null;
                }
            }
        }

    }
}