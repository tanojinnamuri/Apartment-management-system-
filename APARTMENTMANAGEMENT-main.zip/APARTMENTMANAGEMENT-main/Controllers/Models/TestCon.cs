public class TestCon
{
    public int TestConID{get;set;}
    public string dataone{get;set;}
    public string datatwo{get;set;}


}