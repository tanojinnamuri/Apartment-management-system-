using System;
public class GuestDetails
{

    public string guest_Name { get; set; }
    public DateTime entry_Date { get; set; }
    public string block_Id { get; set; }
    public string house_No { get; set; }
    public string guest_Number { get; set; }

}