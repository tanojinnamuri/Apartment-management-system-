using System;
public class AnnouncementDetails
{ 
    
    public string a_text{ get; set; }
    public string a_priority{ get; set; }
    public DateTime a_date{ get; set; }
    public string a_type{ get; set; }  
    public int A_id { get; set; }

}