using System;
public class Reservation
{
    public int ReservationID {get;set; }
 
    public string username{get;set; }
	public int ReservableAreaID{get;set; }
	public DateTime StartTime{get;set; }
	public DateTime EndTime {get;set; }
	public int duration {get;set; } 
	public int  numAttending {get;set; }
	public string  notes   {get;set; }
	public string  ReplyNotes{get;set; }
	public int ResStatusID{get;set; }
	public string TenantName { get; set; }
	public string ResStatus{ get; set; }
	public string ResArea{ get; set; }
	public string phone{get; set; }
}