using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Microsoft.Extensions.Logging;


public class UserInfo
{
    public string emailAddress{get;set;}
    public int userType{get;set;}
    public string firstName{get;set;}
    public string lastName{get;set;}
    public string pwd{get;set;}
    public string phoneNumber{get;set;}

    public UserInfo()
    { }
    public UserInfo(IConfiguration config, ILogger logger)//, ILogger logger, ISession session = null)
    {
        Configuration = config;
        _logger = logger;
    }

private IConfiguration Configuration;
    private ILogger _logger;


    public string updatePwd(UserInfo ui)
    {
        string rv = "";
        using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
        {
            try
            {
                String sql =
                    "updatePwd";
                sconn.Open();
                SqlCommand scmd = sconn.CreateCommand();
                scmd.CommandText = sql;
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.Parameters.AddWithValue("@username", ui.emailAddress);
                scmd.Parameters.AddWithValue("@password", ui.pwd);
                scmd.ExecuteNonQuery();
                rv = string.Empty;
            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error - UpdatePWD");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error - UpdatePWD");
                }
                rv = "there was a problem updating the password";
            }
        }
        return rv;
    }
    public string RemoveUser(string username)
    {
        string rv = "";
        using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
        {
            try
            {
                String sql =
                    "RemoveUser";
                sconn.Open();
                SqlCommand scmd = sconn.CreateCommand();
                scmd.CommandText = sql;
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.Parameters.AddWithValue("@username", username);
                 
                scmd.ExecuteNonQuery();
                rv = string.Empty;
            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error - RemoveUser");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error - RemoveUser");
                }
                rv = "There was a problem removing the user.";
            }
        }
        return rv;
    }

    
}