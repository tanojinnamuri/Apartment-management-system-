using System;
public class ReservableArea
{
    public int ReservableAreaID { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public bool Active { get; set; }
    public int MaxAttendance{ get; set; }
}