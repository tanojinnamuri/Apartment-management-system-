using System;
public class ParkingDetail
{ 
    public String SpaceNumber{get;set; }
    public String UserEmail{ get; set; }
    public string active {get;set; }

    public string tenantName{get;set; }
    public string lotName{ get; set; }
    public string buildingName{ get; set; }
    public string Restype{ get; set; }  
      public int parkingSpaceID { get; set; }

}