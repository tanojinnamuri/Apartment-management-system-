using System;
public class EventDetails
{ 
    
    public string event_Location{ get; set; }
    public string event_Date{ get; set; }
    public string event_Description{ get; set; }  
    public int event_id { get; set; }
    public string event_Name { get; set; }

}