using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Microsoft.Extensions.Logging;
public class StaffInfo
{
    public string username { get; set; }
    public string telephoneNumber { get; set; }
     
    public string Role { get; set; } // the role sec, main,admin
    public int userTypeID { get; set; }
    public string jobTitle { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
    public string password{ get; set; }
    public bool active{ get; set; }
    public StaffInfo()
    { }
    public StaffInfo(IConfiguration config, ILogger logger)//, ILogger logger, ISession session = null)
    {
        Configuration = config;
        _logger = logger;
    }
    private IConfiguration Configuration;
    private ILogger _logger;
    public StaffInfo[] GetAllStaff()
    {
        try
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                String sql = "GetAllStaff";
                SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                sda.Fill(dt);
                var rv = from da in dt.AsEnumerable()
                    select new StaffInfo()
                    {
                        username = da.Field<string>("username"),
                        telephoneNumber = da.Field<string>("telephoneNumber"),
                        userTypeID = da.Field<int>("u_type"),
                        Role = da.Field<string>("UserTypeName"),
                        firstName = da.Field<string>("firstName"),
                        lastName = da.Field<string>("lastName")
                    };
                return rv.ToArray();
            }
        }
        catch (Exception exp)
        {
            _logger.LogError(exp, "Error");
            if (exp.InnerException != null)
            {
                _logger.LogError(exp.InnerException, "Error");
            }
            return null;
        }
    }
    public string AddUpdateStaff(StaffInfo si)
    {
        string rv = "";
        using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
        {
            try
            {
                String sql =
                    "AddUpdateStaff";
                sconn.Open();
                 
                SqlCommand scmd = sconn.CreateCommand();
                scmd.CommandText = sql;
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.Parameters.AddWithValue("@username", si.username);
                scmd.Parameters.AddWithValue("@phone", si.telephoneNumber);
                scmd.Parameters.AddWithValue("@jobTitle", si.jobTitle);
                scmd.Parameters.AddWithValue("@firstName", si.firstName);
                scmd.Parameters.AddWithValue("@lastName", si.lastName);
                 scmd.Parameters.AddWithValue("@userTypeID", si.userTypeID);
                scmd.ExecuteNonQuery();
                rv = string.Empty;
            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error - AddUpdateStaff");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error - AddUpdateStaff");
                    Console.Write(exp.InnerException);
                }
                rv = "there was a problem adding the Staff member";
            }
        }
        return rv;
    }
    public StaffInfo GetStaff( string username)
    {
        try
        {
            using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
            {
                String sql = "GetStaff";
                SqlDataAdapter sda = new SqlDataAdapter(sql, sconn);
                sda.SelectCommand.Parameters.AddWithValue("@username",username);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                sda.Fill(dt);
                var rv = from da in dt.AsEnumerable()
                         select new StaffInfo()
                         {
                             username = da.Field<string>("username"),
                             telephoneNumber = da.Field<string>("telephoneNumber"),
                            // blockId = da.Field<string>("blockId"),
                            // houseID = da.Field<string>("houseID"),
                            // houseNo = da.Field<int>("houseNo"),
                             firstName = da.Field<string>("firstName"),
                             lastName = da.Field<string>("lastName")
                         };
                return rv.FirstOrDefault();
            }
        }
        catch (Exception exp)
        {
            _logger.LogError(exp, "Error");
            if (exp.InnerException != null)
            {
                _logger.LogError(exp.InnerException, "Error");
            }
            return null;
        }
    }
}

