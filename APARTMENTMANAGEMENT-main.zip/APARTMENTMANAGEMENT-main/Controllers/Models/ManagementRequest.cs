using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Microsoft.Extensions.Logging;
public class ManagementRequest
{
    public int requestID { get; set; }
    //Requestor
    public string RequestorID { get; set; }
    public string RequestorPhone { get; set; }
    public string RequestorName { get; set; }
    public string Apartment { get; set; }
    //Handler
    public string HandlerID { get; set; }
    public string handlerName { get; set; }
    public string handlerPhone { get; set; }

    // the request
    public string RequestMessage { get; set; }
    public string ResponseMessage { get; set; }
    public DateTime Requested { get; set; }
    public DateTime? Resolved { get; set; }


    public ManagementRequest()
    { }
    public ManagementRequest(IConfiguration config, ILogger logger)//, ILogger logger, ISession session = null)
    {
        Configuration = config;
        _logger = logger;
    }

    private IConfiguration Configuration;
    private ILogger _logger;

    public string AssignMaintReq(ManagementRequest mr)
    {
        string rv = "";
        using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
        {
            try
            {
                String sql =
                    "AssignMaintReq";
                sconn.Open();
                SqlCommand scmd = sconn.CreateCommand();
                scmd.CommandText = sql;
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.Parameters.AddWithValue("@handlerID", mr.HandlerID);
                scmd.Parameters.AddWithValue("@MainReqID ", mr.requestID);
                scmd.ExecuteNonQuery();
                rv = string.Empty;
            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error - RemoveUser");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error - RemoveUser");
                }
                rv = "There was a problem removing the user.";
            }
        }
        return rv;
    }


    public string ResolveMaintReq(ManagementRequest mr)
    {
        string rv = "";
        using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
        {
            try
            {
                String sql =
                    "ResolveMaintReq";
                sconn.Open();
                SqlCommand scmd = sconn.CreateCommand();
                scmd.CommandText = sql;
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.Parameters.AddWithValue("@MainReqID ", mr.requestID);
                scmd.Parameters.AddWithValue("@ResponseMessage", mr.ResponseMessage);
                scmd.ExecuteNonQuery();
                rv = string.Empty;
            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error - ResolveMaintReq");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error - ResolveMaintReq");
                }
                rv = "There was a problem removing the user.";
            }
        }
        return rv;
    }

    public ManagementRequest[] GetManagementRequests(string managerID, bool closed = false)
    {

        using (SqlConnection sconn = new SqlConnection(Configuration.GetConnectionString("DBConn")))
        {
            string stp = "GetManagementRequests";
            if (closed)
            {
                stp = "GetManagementClosedRequests";

            }
            try
            {

                SqlDataAdapter sda = new SqlDataAdapter(stp, sconn);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (!string.IsNullOrWhiteSpace(managerID))
                {
                    sda.SelectCommand.Parameters.AddWithValue("@HandlerID", managerID);

                }
                DataTable dt = new DataTable();
                sda.Fill(dt);
                var rv = from da in dt.AsEnumerable()
                         select new ManagementRequest()
                         {
                             RequestorName = da.Field<string>("firstName")+ " " + da.Field<string>("lastName"),
                             RequestorPhone = da.Field<string>("phoneNumber"),
                             requestID = da.Field<int>("MainReqID"),
                             RequestorID = da.Field<string>("RequestorUN"),
                             HandlerID = da.Field<string>("HandlerID"),
                             RequestMessage = da.Field<string>("RequestMessage"),
                             ResponseMessage = da.Field<string>("ResponseMessage"),
                             Requested = da.Field<DateTime>("Requested"),
                             Resolved = da.Field<DateTime?>("Resolved"),
                             handlerPhone = da.Field<string>("mphone"),
                             handlerName = da.Field<string>("mfname") + " " + da.Field<string>("mflname"),
                             Apartment =
                                da.Field<string>("blockId") + da.Field<string>("houseID") + Convert.ToString(da.Field<int>("houseNo"))
                         };

                return rv.ToArray();
            }
            catch (Exception exp)
            {
                _logger.LogError(exp, "Error - GetManagementRequests");
                if (exp.InnerException != null)
                {
                    _logger.LogError(exp.InnerException, "Error - GetManagementRequests");

                }
                return null;
            }
        }
    }







}