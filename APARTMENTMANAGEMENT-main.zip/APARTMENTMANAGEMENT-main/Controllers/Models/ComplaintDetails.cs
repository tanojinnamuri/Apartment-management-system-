using System;
public class ComplaintDetails
{ 
    
    public string c_text{ get; set; }
    public string c_requestor{ get; set; }
    public string c_priority{ get; set; }
    public DateTime c_date{ get; set; }
    public string c_type{ get; set; }  
    public int C_id { get; set; }
    public int c_houseNo { get; set; }
    public string c_blockId { get; set; }

}