using System;
public class ApartmentDetails
{
    public string houseID { get; set; }
    public string username { get; set; }
    public int houseNo { get; set; }
    public string blockId { get; set; }

}