﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SE.Controllers
{
    [ApiController]
    [Route("MM/API")]
    public class MaintController : ControllerBase
    {
        private readonly ILogger<MaintController> _logger;

        public IConfiguration Configuration { get; }

        public MaintController(
            IConfiguration configuration,
            ILogger<MaintController> logger
        )
        {
            _logger = logger;
            Configuration = configuration;
        }
        [HttpPost]
        [Route("AssignMaintReq")]
        public JsonResult AssignMaintReq(ManagementRequest mr)
        {
            ManagementRequest t =
                new ManagementRequest(Configuration, _logger );
            return new JsonResult(t.AssignMaintReq(mr));
        }

       [HttpPost]
        [Route("ResolveMaintReq")]
        public JsonResult ResolveMaintReq(ManagementRequest mr)
        {
            ManagementRequest t =
                new ManagementRequest(Configuration, _logger );
            return new JsonResult(t.ResolveMaintReq(mr));
        }     

        [HttpGet]
        [Route("GetClosedRequests")]
        public IEnumerable<ManagementRequest>
        GetClosedRequests(string managerId)
        {
             ManagementRequest t =
                new ManagementRequest(Configuration, _logger );
            return t.GetManagementRequests(managerId,true);
        }

        [HttpGet]
        [Route("GetManagementRequests")]
        public IEnumerable<ManagementRequest>
        GetManagementRequests(string managerId)
        {
            ManagementRequest t =
                new ManagementRequest(Configuration, _logger );
            return t.GetManagementRequests(managerId,false);
        }


    }
}
