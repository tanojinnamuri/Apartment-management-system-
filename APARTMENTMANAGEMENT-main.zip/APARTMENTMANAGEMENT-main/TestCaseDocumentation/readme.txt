Test cases for each build will be put here
